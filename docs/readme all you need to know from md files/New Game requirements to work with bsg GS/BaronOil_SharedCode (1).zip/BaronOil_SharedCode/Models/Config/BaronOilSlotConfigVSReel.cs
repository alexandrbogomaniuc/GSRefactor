using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigVSReel: IWeightedItem
{
    public int[] Reels { get; init; } = [];
    public int Weight { get; init; }
}