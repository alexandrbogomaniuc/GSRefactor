using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfig : SlotConfig
{
    public int MaxWin { get; init; }
    public int BaseBet { get; init; }
    public required int[][] BaseSet { get; init; }
    public required int[][] BuyBonusBaseReelSet { get; init; }
    public required int[][] TrainFreeSpinsReelSet { get; init; }
    public required int[][] BuyBonusDeadCollectReelSet { get; init; }
    public required int[][] DeadCollectReelSet { get; init; }
    public required int[][] DuelFreeSpinsReelSet { get; init; }
    public required int[][] BuyBonusDeadShowDownReelSet { get; init; }
    public required int[][] DeadShowDownReelSet { get; init; }
    public int BetMultiplier { get; init; }
    public override int BaseLines => 1;
    public int TranBuyBonus { get; init; }
    public int DeadBuyBonus { get; init; }
    public int DuelBuyBonus { get; init; }
    public int DeadPositionsCount { get; init; }
    public int TrainPositionsCount { get; init; }
    public int DuelPositionsCount { get; init; }
    public required BaronOilSlotConfigBaseGameType[] BaseGameType { get; init; }
    public required BaronOilSlotConfigVS[] VS { get; init; }
    public required BaronOilSlotConfigVS[] DuelFreeSpinsVS { get; init; }
    public required BaronOilSlotConfigVS[] BuyBonusVS { get; init; }
    public required BaronOilSlotConfigVSMultiplier[] VSMultipers { get; init; }
    public required BaronOilSlotConfigVSMultiplier[] BuyBonusVSMultipers { get; init; }
    public required BaronOilSlotConfigVSWinnerRule[] VSWinnerRules { get; init; }
    public required BaronOilSlotConfigScatter[] Scatter { get; init; }
    public required BaronOilSlotConfigScatterType[] ScatterType { get; init; }
    public required BaronOilSlotConfigScatterInfo[] ScattersInfo { get; init; }
    public required BaronOilSlotConfigTrainFreeSpinsWild[] TrainFreeSpinsWilds { get; init; }
    public required BaronOilSlotConfigTrainFreeSpinsWild[] TrainBuyBonusWilds { get; init; }
}
