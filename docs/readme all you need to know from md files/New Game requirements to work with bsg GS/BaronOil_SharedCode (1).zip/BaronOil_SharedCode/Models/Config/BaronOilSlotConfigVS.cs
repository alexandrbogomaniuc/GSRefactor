using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigVS: IWeightedItem
{
    public int Count { get; init; }
    public int Weight { get; init; }
    public required BaronOilSlotConfigVSReel[] ReelWeights { get; init; } = [];
}