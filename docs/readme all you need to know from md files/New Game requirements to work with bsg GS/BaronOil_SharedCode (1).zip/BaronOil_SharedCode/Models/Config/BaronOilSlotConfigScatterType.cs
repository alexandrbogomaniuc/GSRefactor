using CGS.Games.Slots.BaronOil.Constants;
using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;
public class BaronOilSlotConfigScatterType : IWeightedItem
{
    public BaronOilScatterTypeEnum Type { get; init; } = BaronOilScatterTypeEnum.Empty;
    public int Weight { get; init; }
}