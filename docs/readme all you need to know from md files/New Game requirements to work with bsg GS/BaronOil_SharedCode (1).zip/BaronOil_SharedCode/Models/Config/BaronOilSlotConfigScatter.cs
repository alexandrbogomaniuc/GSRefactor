using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;
public class BaronOilSlotConfigScatter : IWeightedItem
{
    public int Count { get; init; }
    public int Weight { get; init; }
}