namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigScatterInfo
{
    public int ScattersAmount { get; init; }
    public int TrainFreeSpinsAmount { get; init; }
    public int DeadFreeSpinsAmount { get; init; }
    public int DuelFreeSpinsAmount { get; init; }
}