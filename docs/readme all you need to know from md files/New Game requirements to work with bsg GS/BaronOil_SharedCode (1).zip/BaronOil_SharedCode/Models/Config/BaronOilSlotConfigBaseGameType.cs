using CGS.Games.Slots.BaronOil.Constants;
using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;


public class BaronOilSlotConfigBaseGameType : IWeightedItem
{
    public BaronOilBaseGameTypeEnum Type { get; init; } = BaronOilBaseGameTypeEnum.Empty;
    public int Weight { get; init; }
}