using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigVSWinnerRule
{
    public int Difference { get; init; }
    public BaronOilSlotConfigVSWinnerRuleItem[] Weights { get; init; } = [];
}