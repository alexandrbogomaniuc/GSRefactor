using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigTrainFreeSpinsWild : IWeightedItem
{
    public int Count { get; init; }
    public int Weight { get; init; }
}