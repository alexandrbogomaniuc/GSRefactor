using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigVSMultiplier: IWeightedItem
{
    public int Multiplier { get; init; }
    public int Weight { get; init; }
}