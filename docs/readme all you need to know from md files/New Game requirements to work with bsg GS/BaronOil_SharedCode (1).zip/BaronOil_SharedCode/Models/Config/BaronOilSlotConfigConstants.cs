namespace CGS.Games.Slots.BaronOil.Models.Config;

public static class BaronOilSlotConfigConstants
{
    public const int VSIconId = 16;
}