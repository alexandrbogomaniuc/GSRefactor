using CGS.SlotEngine.Slot.Models.Config;

namespace CGS.Games.Slots.BaronOil.Models.Config;

public class BaronOilSlotConfigVSWinnerRuleItem: IWeightedItem
{
    public int Result { get; init; }
    public int Weight { get; init; }
}