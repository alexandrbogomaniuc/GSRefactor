using CGS.SlotEngine.Models.Rtp;

namespace CGS.Games.Slots.BaronOil.Models.Rtp;

public class BaronOilFeatureDetails
{
    public int Count { get; set; }
    public double HitRate { get; set; }
}

public class BaronOilVSFeaturePayStatics
{
    public double TotalWin { get; set; }
    public int Count { get; set; }
}

public class BaronOilVSFeatureDetails
{
    public int Count { get; set; }
    public int MultiplierCount { get; set; }
    public int VsItemCount { get; set; }
    public double AverageMultiplier { get; set; }
    public double HitRate { get; set; }
    public int VS1Count { get; set; }
    public int VS1TriggerCount { get; set; }
    public int VS2Count { get; set; }
    public int VS2TriggerCount { get; set; }
    public int VS3Count { get; set; }
    public int VS3TriggerCount { get; set; }
    public int VS4Count { get; set; }
    public int VS4TriggerCount { get; set; }
    public int VS5Count { get; set; }
    public int VS5TriggerCount { get; set; }

    public double VS1TotalWin { get; set; }
    public double VS2TotalWin { get; set; }
    public double VS3TotalWin { get; set; }
    public double VS4TotalWin { get; set; }
    public double VS5TotalWin { get; set; }

    public int SpinsWithVsTriggered { get; set; }
    public long SumOfAllAppliedMultipliers { get; set; }
    public int TotalBattles { get; set; }
    public double AverageWinningMultiplier { get; set; }
    public int TotalVsAppearances { get; set; }
    public double VsTriggerCycle { get; set; }
    public double VsTriggeredPercent { get; set; }
    public double VsAppearancesPercent { get; set; }
    public double SumOfBaseWins { get; set; }
    public double SumOfMultipliedWins { get; set; }
    public double NonVsSpinsWin { get; set; }
    public int NonVsSpinsCount { get; set; }
    public double NonTriggeredVsWin { get; set; }
}


public class BaronOilDeadBonusDetails
{
    public int WildCount { get; set; }
    public int MultiplierCount { get; set; }
    public double HitRate { get; set; }
}

public class BaronOilFreeSpinsDetails
{
    public int StartedCount { get; set; }
    public double StartedHitRate { get; set; }
    public int TotalRoundsCount { get; set; }
    public required BaronOilFeatureDetails WildAppears { get; set; }
    public required BaronOilFeatureDetails MaxWinFeature { get; set; }
}

public class BaroinOilExtendedFreeSpin
{
    public int TriggeredCount { get; set; }
    public int SpinCount { get; set; }
    public int TotalSpins { get; set; }
    public double TotalWin { get; set; }
    public double BaseGameWin { get; set; }
    public long TotalWildsAdded { get; set; }
    public long TotalWildsCollected { get; set; }
    public long TotalMultipliersCollected { get; set; }
    public double AverageWildsAdded { get; set; }
    public double AverageWilds { get; set; }
    public double AverageMultipliers { get; set; }
}

public class BaronOilExtendedRtpData
{
    public BaroinOilExtendedFreeSpin Duel { get; set; } = new();
    public BaroinOilExtendedFreeSpin Train { get; set; } = new();
    public BaroinOilExtendedFreeSpin Dead { get; set; } = new();
}

public class BaronOilWinDistribution
{
    public int Win0 { get; set; }
    public int Win0To05 { get; set; }
    public int Win05To1 { get; set; }
    public int Win1To2 { get; set; }
    public int Win2To3 { get; set; }
    public int Win3To5 { get; set; }
    public int Win5To10 { get; set; }
    public int Win10To15 { get; set; }
    public int Win15To20 { get; set; }
    public int Win20To30 { get; set; }
    public int Win30To50 { get; set; }
    public int Win50To75 { get; set; }
    public int Win75To100 { get; set; }
    public int Win100To150 { get; set; }
    public int Win150Plus { get; set; }
}

public class BaronOilBaseGameStats
{
    public double NonVsWin { get; set; }
    public double VsWin { get; set; }
    public int NonVsSpinCount { get; set; }
    public int VsSpinCount { get; set; }
    public int NonVsHitCount { get; set; }
    public int VsHitCount { get; set; }
    public string NonVsRtp { get; set; } = "0%";
    public string VsRtp { get; set; } = "0%";
    public string NonVsHitRate { get; set; } = "0%";
    public string VsHitRate { get; set; } = "0%";
}

public class BaronOilRtpData : RtpData
{
    public required BaronOilFreeSpinsDetails FreeSpins { get; set; }
    public BaronOilVSFeatureDetails VS { get; set; } = new();
    public BaronOilVSFeaturePayStatics[] PayStatics { get; set; } = [];
    public required BaronOilFeatureDetails TrainBonus { get; set; }
    public required BaronOilDeadBonusDetails DeadBonus { get; set; }
    public required BaronOilExtendedRtpData FreeSpinsRtpData { get; set; }
    public required int TrainMaxWin { get; set; }
    public BaronOilBaseGameStats BaseGameStats { get; set; } = new();
    public BaronOilWinDistribution WinDistribution { get; set; } = new();
    public WinDetails WinUncapped { get; set; } = new();
    public RtpDetails RtpUncapped { get; set; } = new();
}
