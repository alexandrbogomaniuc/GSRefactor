using CGS.Common.Attributes;
using CGS.Common.Services.Logger;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Rtp;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Models.Params;
using CGS.SlotEngine.Models.Rtp;
using CGS.SlotEngine.Services.Bets;
using CGS.SlotEngine.Services.RtpCalculator;
using CGS.SlotEngine.Services.Slot;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Services;

[Scoped(typeof(RtpCalculatorService), "machine8")]
public class BaronOilRtpCalculatorService : RtpCalculatorService
{
    private static long _globalSpinCounter;

    public BaronOilRtpCalculatorService(SlotService slotService, IBetsService betsService,
        IApplicationLogger<RtpCalculatorService> applicationLogger)
        : base(slotService, betsService, applicationLogger)
    {
        MachineId = 8;
    }

    protected override async Task<RtpData> Execute(RtpParams rtpParams)
    {
        if (!string.IsNullOrEmpty(rtpParams.Feature))
        {
            return rtpParams.Parallel != null
                ? await ParallelExecuteBuyBonus(rtpParams)
                : await SequenceExecuteBuyBonus(rtpParams);
        }

        return rtpParams.Parallel != null
            ? await ParallelExecute(rtpParams)
            : await SequenceExecute(rtpParams);
    }

    private async Task<RtpData> SequenceExecute(RtpParams rtpParams)
    {
        var machineState = MachineState.GetDefaultState(MachineId);
        var startParams = new StartParams { MachineId = MachineId };
        var startState = await _slotService.StartMachine(startParams, machineState);

        double userBalance = DefaultBalance;
        machineState = startState.MachineState;

        var rtpResponse = GetInitialRtpResponse();
        var totalSpins = rtpParams.SpinsCount ?? DefaultSpinsCout;

        for (int i = 0; i < totalSpins; i++)
        {
            var spinState = await DoSpin(rtpResponse, machineState);
            userBalance = UpdateUserBalance(spinState, userBalance);
            machineState = spinState.MachineState;

            if (machineState.FreeSpinsInfo != null)
            {
                while (machineState.FreeSpinsInfo!.Event != FreeSpinsEvent.finished)
                {
                    spinState = await DoSpin(rtpResponse, machineState);
                    userBalance = UpdateUserBalance(spinState, userBalance);
                    machineState = spinState.MachineState;
                }
                CollectFreeSpinsRtpData(machineState, rtpResponse);
            }

            if (i % LogResult == 0)
            {
                Log($"RTP calculation progress: {i} spins");
            }

            rtpResponse.TotalSpins = i + 1;
            rtpResponse.PayStatics = rtpResponse.PayStatics.OrderBy(statics => statics.TotalWin).ToArray();
            UpdateIntermediateRtp(rtpResponse, totalSpins);
        }

        UpdateTotalRtp(rtpResponse, userBalance);
        return rtpResponse;
    }

    private async Task<RtpData> ParallelExecute(RtpParams rtpParams)
    {
        _globalSpinCounter = 0;

        var threads = Math.Max(1, rtpParams.Parallel!.Value);
        var totalSpins = rtpParams.SpinsCount ?? DefaultSpinsCout;
        var spinsPerThread = totalSpins / threads;
        var remainder = totalSpins % threads;

        var tasks = new List<Task<BaronOilRtpData>>();

        for (var t = 0; t < threads; t++)
        {
            var spins = spinsPerThread + (t == 0 ? remainder : 0);
            tasks.Add(Task.Run(() => CalculateRtpThreadAsync(spins)));
        }

        var results = await Task.WhenAll(tasks);

        var merged = GetInitialRtpResponse();

        foreach (var r in results)
        {
            merged.Win.BaseGameWin += r.Win.BaseGameWin;
            merged.Win.FreeSpinsWin += r.Win.FreeSpinsWin;
            merged.Win.TotalLoose += r.Win.TotalLoose;
            merged.WinUncapped.BaseGameWin += r.WinUncapped.BaseGameWin;
            merged.WinUncapped.FreeSpinsWin += r.WinUncapped.FreeSpinsWin;
            merged.FreeSpins.StartedCount += r.FreeSpins.StartedCount;
            merged.FreeSpins.TotalRoundsCount += r.FreeSpins.TotalRoundsCount;
            merged.FreeSpins.WildAppears.Count += r.FreeSpins.WildAppears.Count;
            merged.FreeSpins.MaxWinFeature.Count += r.FreeSpins.MaxWinFeature.Count;
            merged.VS.Count += r.VS.Count;
            merged.TotalSpins += r.TotalSpins;

            merged.FreeSpinsRtpData.Duel.TriggeredCount += r.FreeSpinsRtpData.Duel.TriggeredCount;
            merged.FreeSpinsRtpData.Train.TriggeredCount += r.FreeSpinsRtpData.Train.TriggeredCount;
            merged.FreeSpinsRtpData.Dead.TriggeredCount += r.FreeSpinsRtpData.Dead.TriggeredCount;

            merged.FreeSpinsRtpData.Duel.SpinCount += r.FreeSpinsRtpData.Duel.SpinCount;
            merged.FreeSpinsRtpData.Train.SpinCount += r.FreeSpinsRtpData.Train.SpinCount;
            merged.FreeSpinsRtpData.Dead.SpinCount += r.FreeSpinsRtpData.Dead.SpinCount;

            merged.FreeSpinsRtpData.Duel.TotalWin += r.FreeSpinsRtpData.Duel.TotalWin;
            merged.FreeSpinsRtpData.Train.TotalWin += r.FreeSpinsRtpData.Train.TotalWin;
            merged.FreeSpinsRtpData.Dead.TotalWin += r.FreeSpinsRtpData.Dead.TotalWin;

            merged.FreeSpinsRtpData.Duel.BaseGameWin += r.FreeSpinsRtpData.Duel.BaseGameWin;
            merged.FreeSpinsRtpData.Train.BaseGameWin += r.FreeSpinsRtpData.Train.BaseGameWin;
            merged.FreeSpinsRtpData.Dead.BaseGameWin += r.FreeSpinsRtpData.Dead.BaseGameWin;
            merged.FreeSpinsRtpData.Train.TotalWildsAdded += r.FreeSpinsRtpData.Train.TotalWildsAdded;
            merged.FreeSpinsRtpData.Dead.TotalWildsCollected += r.FreeSpinsRtpData.Dead.TotalWildsCollected;
            merged.FreeSpinsRtpData.Dead.TotalMultipliersCollected += r.FreeSpinsRtpData.Dead.TotalMultipliersCollected;

            merged.BaseGameStats.NonVsSpinCount += r.BaseGameStats.NonVsSpinCount;
            merged.BaseGameStats.VsSpinCount += r.BaseGameStats.VsSpinCount;
            merged.BaseGameStats.NonVsWin += r.BaseGameStats.NonVsWin;
            merged.BaseGameStats.VsWin += r.BaseGameStats.VsWin;
            merged.BaseGameStats.NonVsHitCount += r.BaseGameStats.NonVsHitCount;
            merged.BaseGameStats.VsHitCount += r.BaseGameStats.VsHitCount;

            merged.VS.VS1Count += r.VS.VS1Count;
            merged.VS.VS2Count += r.VS.VS2Count;
            merged.VS.VS3Count += r.VS.VS3Count;
            merged.VS.VS4Count += r.VS.VS4Count;
            merged.VS.VS5Count += r.VS.VS5Count;
            merged.VS.VS1TotalWin += r.VS.VS1TotalWin;
            merged.VS.VS2TotalWin += r.VS.VS2TotalWin;
            merged.VS.VS3TotalWin += r.VS.VS3TotalWin;
            merged.VS.VS4TotalWin += r.VS.VS4TotalWin;
            merged.VS.VS5TotalWin += r.VS.VS5TotalWin;

            merged.VS.SpinsWithVsTriggered += r.VS.SpinsWithVsTriggered;
            merged.VS.SumOfAllAppliedMultipliers += r.VS.SumOfAllAppliedMultipliers;
            merged.VS.TotalBattles += r.VS.TotalBattles;
            merged.VS.TotalVsAppearances += r.VS.TotalVsAppearances;
            merged.VS.SumOfBaseWins += r.VS.SumOfBaseWins;
            merged.VS.SumOfMultipliedWins += r.VS.SumOfMultipliedWins;
            merged.VS.NonVsSpinsCount += r.VS.NonVsSpinsCount;
            merged.VS.NonVsSpinsWin += r.VS.NonVsSpinsWin;
            merged.VS.NonTriggeredVsWin += r.VS.NonTriggeredVsWin;
        }

        double avgEndBalance = results.Sum(r => r.User.EndBalance) / threads;
        UpdateTotalRtp(merged, avgEndBalance);

        return merged;
    }

    private Task<BaronOilRtpData> CalculateRtpThreadAsync(int spinsCount)
    {
        return Task.FromResult(CalculateRtpThreadSync(spinsCount));
    }

    private BaronOilRtpData CalculateRtpThreadSync(int spinsCount)
    {
        var machineState = MachineState.GetDefaultState(MachineId);
        var startParams = new StartParams { MachineId = MachineId };
        var startState = _slotService.StartMachine(startParams, machineState).GetAwaiter().GetResult();
        var userBalance = DefaultBalance;
        machineState = startState.MachineState;
        var rtpResponse = GetInitialRtpResponse();

        var machine = _slotService.GetSlotMachine(MachineId);
        var spinParams = new SpinParams { Bet = 20, MachineId = MachineId };

        var i = 0;
        while (i < spinsCount)
        {
            var spinState = machine.SpinSync(machineState, spinParams);
            UpdateSpinRtp(spinState, rtpResponse);

            userBalance = UpdateUserBalance(spinState, userBalance);
            machineState = spinState.MachineState;

            if (machineState.FreeSpinsInfo != null)
            {
                while (machineState.FreeSpinsInfo!.Event != FreeSpinsEvent.finished)
                {
                    spinState = machine.SpinSync(machineState, spinParams);
                    UpdateSpinRtp(spinState, rtpResponse);
                    userBalance = UpdateUserBalance(spinState, userBalance);
                    machineState = spinState.MachineState;
                }
                CollectFreeSpinsRtpData(machineState, rtpResponse);
            }

            i++;

            if (i % 1_000_000 == 0)
            {
                long global = Interlocked.Add(ref _globalSpinCounter, 1_000_000);
                Log($"[GLOBAL] Прогресс: {global} спинов выполнено всеми потоками");
            }
        }

        Interlocked.Add(ref _globalSpinCounter, i % 1_000_000);
        rtpResponse.TotalSpins = spinsCount;

        UpdateTotalRtp(rtpResponse, userBalance);
        return rtpResponse;
    }

    #region Buy Bonus RTP Calculation

    private async Task<RtpData> SequenceExecuteBuyBonus(RtpParams rtpParams)
    {
        var machineState = MachineState.GetDefaultState(MachineId);
        var startParams = new StartParams { MachineId = MachineId };
        var startState = await _slotService.StartMachine(startParams, machineState);

        double userBalance = DefaultBalance;
        machineState = startState.MachineState;

        var rtpResponse = GetInitialRtpResponse();
        var totalSpins = rtpParams.SpinsCount ?? DefaultSpinsCout;

        var buyBonusParams = GetBuyBonusParamsByFeature(rtpParams.Feature!);
        var bonusCost = GetBonusCost(rtpParams.Feature!);

        for (int i = 0; i < totalSpins; i++)
        {
            var spinState = await _slotService.BuyFreeSpins(buyBonusParams, machineState);
            userBalance -= bonusCost;
            machineState = spinState.MachineState;

            while (machineState.FreeSpinsInfo != null && machineState.FreeSpinsInfo.Event != FreeSpinsEvent.finished)
            {
                spinState = await DoSpin(rtpResponse, machineState);
                machineState = spinState.MachineState;
            }

            if (machineState.FreeSpinsInfo != null)
            {
                userBalance += machineState.FreeSpinsInfo.TotalWin;
                rtpResponse.Win.FreeSpinsWin += machineState.FreeSpinsInfo.TotalWin;
                rtpResponse.WinUncapped.FreeSpinsWin += GetUncappedFreeSpinsWin(machineState);
                rtpResponse.Win.TotalLoose += bonusCost;
                CollectFreeSpinsRtpData(machineState, rtpResponse);
                TrackWinDistribution(machineState.FreeSpinsInfo.TotalWin, bonusCost, rtpResponse);
            }

            machineState = MachineState.GetDefaultState(MachineId);
            startState = await _slotService.StartMachine(startParams, machineState);
            machineState = startState.MachineState;

            if (i % LogResult == 0)
            {
                Log($"Buy Bonus RTP [{rtpParams.Feature}] progress: {i} bonuses");
            }

            rtpResponse.TotalSpins = i + 1;
        }

        UpdateBuyBonusRtp(rtpResponse, userBalance, totalSpins, bonusCost);
        return rtpResponse;
    }

    private async Task<RtpData> ParallelExecuteBuyBonus(RtpParams rtpParams)
    {
        _globalSpinCounter = 0;

        var threads = Math.Max(1, rtpParams.Parallel!.Value);
        var totalSpins = rtpParams.SpinsCount ?? DefaultSpinsCout;
        var spinsPerThread = totalSpins / threads;
        var remainder = totalSpins % threads;

        var tasks = new List<Task<BaronOilRtpData>>();

        for (var t = 0; t < threads; t++)
        {
            var spins = spinsPerThread + (t == 0 ? remainder : 0);
            var feature = rtpParams.Feature!;
            tasks.Add(Task.Run(() => CalculateBuyBonusRtpThreadSync(spins, feature)));
        }

        var results = await Task.WhenAll(tasks);

        var merged = GetInitialRtpResponse();
        var bonusCost = GetBonusCost(rtpParams.Feature!);

        foreach (var r in results)
        {
            merged.Win.FreeSpinsWin += r.Win.FreeSpinsWin;
            merged.Win.TotalLoose += r.Win.TotalLoose;
            merged.WinUncapped.BaseGameWin += r.WinUncapped.BaseGameWin;
            merged.WinUncapped.FreeSpinsWin += r.WinUncapped.FreeSpinsWin;
            merged.FreeSpins.StartedCount += r.FreeSpins.StartedCount;
            merged.FreeSpins.TotalRoundsCount += r.FreeSpins.TotalRoundsCount;
            merged.FreeSpins.WildAppears.Count += r.FreeSpins.WildAppears.Count;
            merged.TotalSpins += r.TotalSpins;

            merged.FreeSpinsRtpData.Duel.TriggeredCount += r.FreeSpinsRtpData.Duel.TriggeredCount;
            merged.FreeSpinsRtpData.Train.TriggeredCount += r.FreeSpinsRtpData.Train.TriggeredCount;
            merged.FreeSpinsRtpData.Dead.TriggeredCount += r.FreeSpinsRtpData.Dead.TriggeredCount;

            merged.FreeSpinsRtpData.Duel.SpinCount += r.FreeSpinsRtpData.Duel.SpinCount;
            merged.FreeSpinsRtpData.Train.SpinCount += r.FreeSpinsRtpData.Train.SpinCount;
            merged.FreeSpinsRtpData.Dead.SpinCount += r.FreeSpinsRtpData.Dead.SpinCount;

            merged.FreeSpinsRtpData.Duel.TotalWin += r.FreeSpinsRtpData.Duel.TotalWin;
            merged.FreeSpinsRtpData.Train.TotalWin += r.FreeSpinsRtpData.Train.TotalWin;
            merged.FreeSpinsRtpData.Dead.TotalWin += r.FreeSpinsRtpData.Dead.TotalWin;

            merged.FreeSpinsRtpData.Train.TotalWildsAdded += r.FreeSpinsRtpData.Train.TotalWildsAdded;
            merged.FreeSpinsRtpData.Dead.TotalWildsCollected += r.FreeSpinsRtpData.Dead.TotalWildsCollected;
            merged.FreeSpinsRtpData.Dead.TotalMultipliersCollected += r.FreeSpinsRtpData.Dead.TotalMultipliersCollected;

            merged.VS.Count += r.VS.Count;
            merged.VS.VS1Count += r.VS.VS1Count;
            merged.VS.VS2Count += r.VS.VS2Count;
            merged.VS.VS3Count += r.VS.VS3Count;
            merged.VS.VS4Count += r.VS.VS4Count;
            merged.VS.VS5Count += r.VS.VS5Count;

            merged.VS.VS1TriggerCount += r.VS.VS1TriggerCount;
            merged.VS.VS2TriggerCount += r.VS.VS2TriggerCount;
            merged.VS.VS3TriggerCount += r.VS.VS3TriggerCount;
            merged.VS.VS4TriggerCount += r.VS.VS4TriggerCount;
            merged.VS.VS5TriggerCount += r.VS.VS5TriggerCount;

            merged.VS.SpinsWithVsTriggered += r.VS.SpinsWithVsTriggered;
            merged.VS.SumOfAllAppliedMultipliers += r.VS.SumOfAllAppliedMultipliers;
            merged.VS.TotalBattles += r.VS.TotalBattles;
            merged.VS.TotalVsAppearances += r.VS.TotalVsAppearances;
            merged.VS.SumOfBaseWins += r.VS.SumOfBaseWins;
            merged.VS.SumOfMultipliedWins += r.VS.SumOfMultipliedWins;
            merged.VS.NonVsSpinsCount += r.VS.NonVsSpinsCount;
            merged.VS.NonVsSpinsWin += r.VS.NonVsSpinsWin;
            merged.VS.NonTriggeredVsWin += r.VS.NonTriggeredVsWin;

            merged.WinDistribution.Win0 += r.WinDistribution.Win0;
            merged.WinDistribution.Win0To05 += r.WinDistribution.Win0To05;
            merged.WinDistribution.Win05To1 += r.WinDistribution.Win05To1;
            merged.WinDistribution.Win1To2 += r.WinDistribution.Win1To2;
            merged.WinDistribution.Win2To3 += r.WinDistribution.Win2To3;
            merged.WinDistribution.Win3To5 += r.WinDistribution.Win3To5;
            merged.WinDistribution.Win5To10 += r.WinDistribution.Win5To10;
            merged.WinDistribution.Win10To15 += r.WinDistribution.Win10To15;
            merged.WinDistribution.Win15To20 += r.WinDistribution.Win15To20;
            merged.WinDistribution.Win20To30 += r.WinDistribution.Win20To30;
            merged.WinDistribution.Win30To50 += r.WinDistribution.Win30To50;
            merged.WinDistribution.Win50To75 += r.WinDistribution.Win50To75;
            merged.WinDistribution.Win75To100 += r.WinDistribution.Win75To100;
            merged.WinDistribution.Win100To150 += r.WinDistribution.Win100To150;
            merged.WinDistribution.Win150Plus += r.WinDistribution.Win150Plus;
        }

        double avgEndBalance = results.Sum(r => r.User.EndBalance) / threads;
        UpdateBuyBonusRtp(merged, avgEndBalance, totalSpins, bonusCost);

        return merged;
    }

    private BaronOilRtpData CalculateBuyBonusRtpThreadSync(int bonusCount, string feature)
    {
        var machineState = MachineState.GetDefaultState(MachineId);
        var startParams = new StartParams { MachineId = MachineId };
        var startState = _slotService.StartMachine(startParams, machineState).GetAwaiter().GetResult();

        var userBalance = DefaultBalance;
        machineState = startState.MachineState;
        var rtpResponse = GetInitialRtpResponse();

        var machine = _slotService.GetSlotMachine(MachineId);
        var buyBonusParams = GetBuyBonusParamsByFeature(feature);
        var bonusCost = GetBonusCost(feature);

        for (int i = 0; i < bonusCount; i++)
        {
            var spinState = machine.BuyFreeSpins(machineState, buyBonusParams).GetAwaiter().GetResult();
            userBalance -= bonusCost;
            machineState = spinState.MachineState;
            rtpResponse.FreeSpins.StartedCount++;

            var spinParams = new SpinParams { Bet = 20, MachineId = MachineId };
            while (machineState.FreeSpinsInfo != null && machineState.FreeSpinsInfo.Event != FreeSpinsEvent.finished)
            {
                spinState = machine.SpinSync(machineState, spinParams);
                rtpResponse.FreeSpins.TotalRoundsCount++;

                if (feature.Equals("duel", StringComparison.OrdinalIgnoreCase))
                {
                    TrackVSInFreeSpins(spinState, rtpResponse);
                }

                UpdateWildDetails(spinState, rtpResponse);
                machineState = spinState.MachineState;
            }

            if (machineState.FreeSpinsInfo != null)
            {
                userBalance += machineState.FreeSpinsInfo.TotalWin;
                rtpResponse.Win.FreeSpinsWin += machineState.FreeSpinsInfo.TotalWin;
                rtpResponse.WinUncapped.FreeSpinsWin += GetUncappedFreeSpinsWin(machineState);
                rtpResponse.Win.TotalLoose += bonusCost;
                CollectFreeSpinsRtpData(machineState, rtpResponse);
                TrackWinDistribution(machineState.FreeSpinsInfo.TotalWin, bonusCost, rtpResponse);
            }

            machineState = MachineState.GetDefaultState(MachineId);
            startState = _slotService.StartMachine(startParams, machineState).GetAwaiter().GetResult();
            machineState = startState.MachineState;

            if (i % 100_000 == 0 && i > 0)
            {
                long global = Interlocked.Add(ref _globalSpinCounter, 100_000);
                Log($"[Buy Bonus {feature}] Progress: {global} bonuses completed");
            }
        }

        Interlocked.Add(ref _globalSpinCounter, bonusCount % 100_000);
        rtpResponse.TotalSpins = bonusCount;
        rtpResponse.User.EndBalance = userBalance;

        return rtpResponse;
    }

    private void TrackVSInFreeSpins(SpinState spinState, BaronOilRtpData rtpResponse)
    {
        var machineState = spinState.MachineState;
        var rtpVSData = BaronOilMachineStatePayload.GetRTPVSData(machineState.Payload);
        if (rtpVSData != null && rtpVSData.ContainsKey("VsItemCount"))
        {
            var vsCount = Convert.ToInt32(rtpVSData["VsItemCount"]);
            var multiplier = rtpVSData.ContainsKey("Multiplier") ? Convert.ToInt32(rtpVSData["Multiplier"]) : 1;
            var totalWin = rtpVSData.ContainsKey("TotalWin") ? Convert.ToDouble(rtpVSData["TotalWin"]) : 0;
            var vsTriggered = multiplier > 1;

            if (vsCount == 0)
            {
                rtpResponse.VS.NonVsSpinsCount++;
                rtpResponse.VS.NonVsSpinsWin += totalWin;
            }
            else
            {
                rtpResponse.VS.Count++;
                rtpResponse.VS.TotalVsAppearances += vsCount;

                switch (vsCount)
                {
                    case 1: rtpResponse.VS.VS1Count++; break;
                    case 2: rtpResponse.VS.VS2Count++; break;
                    case 3: rtpResponse.VS.VS3Count++; break;
                    case 4: rtpResponse.VS.VS4Count++; break;
                    case 5: rtpResponse.VS.VS5Count++; break;
                }

                if (vsTriggered)
                {
                    rtpResponse.VS.SpinsWithVsTriggered++;
                    rtpResponse.VS.SumOfAllAppliedMultipliers += multiplier;
                    rtpResponse.VS.TotalBattles += vsCount;

                    var baseWin = rtpVSData.ContainsKey("BaseWin") ? Convert.ToDouble(rtpVSData["BaseWin"]) : 0;
                    rtpResponse.VS.SumOfBaseWins += baseWin;
                    rtpResponse.VS.SumOfMultipliedWins += totalWin;

                    switch (vsCount)
                    {
                        case 1: rtpResponse.VS.VS1TriggerCount++; break;
                        case 2: rtpResponse.VS.VS2TriggerCount++; break;
                        case 3: rtpResponse.VS.VS3TriggerCount++; break;
                        case 4: rtpResponse.VS.VS4TriggerCount++; break;
                        case 5: rtpResponse.VS.VS5TriggerCount++; break;
                    }
                }
                else
                {
                    rtpResponse.VS.NonTriggeredVsWin += totalWin;
                }
            }
        }
    }

    private void TrackVSInBaseGame(SpinState spinState, BaronOilRtpData rtpResponse)
    {
        var machineState = spinState.MachineState;
        var rtpVSData = BaronOilMachineStatePayload.GetRTPVSData(machineState.Payload);
        var totalWin = machineState.TotalWin;

        if (rtpVSData == null || !rtpVSData.ContainsKey("VsItemCount"))
        {
            rtpResponse.VS.NonVsSpinsCount++;
            rtpResponse.VS.NonVsSpinsWin += totalWin;
            return;
        }

        var vsCount = Convert.ToInt32(rtpVSData["VsItemCount"]);
        var multiplier = rtpVSData.ContainsKey("Multiplier") ? Convert.ToInt32(rtpVSData["Multiplier"]) : 1;
        var win = rtpVSData.ContainsKey("TotalWin") ? Convert.ToDouble(rtpVSData["TotalWin"]) : totalWin;
        var baseWin = rtpVSData.ContainsKey("BaseWin") ? Convert.ToDouble(rtpVSData["BaseWin"]) : win;
        var vsTriggered = multiplier > 1;

        if (vsCount == 0)
        {
            rtpResponse.VS.NonVsSpinsCount++;
            rtpResponse.VS.NonVsSpinsWin += win;
            return;
        }

        rtpResponse.VS.Count++;
        rtpResponse.VS.TotalVsAppearances += vsCount;

        switch (vsCount)
        {
            case 1:
                rtpResponse.VS.VS1Count++;
                rtpResponse.VS.VS1TotalWin += win;
                break;
            case 2:
                rtpResponse.VS.VS2Count++;
                rtpResponse.VS.VS2TotalWin += win;
                break;
            case 3:
                rtpResponse.VS.VS3Count++;
                rtpResponse.VS.VS3TotalWin += win;
                break;
            case 4:
                rtpResponse.VS.VS4Count++;
                rtpResponse.VS.VS4TotalWin += win;
                break;
            case 5:
                rtpResponse.VS.VS5Count++;
                rtpResponse.VS.VS5TotalWin += win;
                break;
        }

        if (vsTriggered)
        {
            rtpResponse.VS.SpinsWithVsTriggered++;
            rtpResponse.VS.SumOfAllAppliedMultipliers += multiplier;
            rtpResponse.VS.TotalBattles += vsCount;
            rtpResponse.VS.SumOfBaseWins += baseWin;
            rtpResponse.VS.SumOfMultipliedWins += win;

            switch (vsCount)
            {
                case 1: rtpResponse.VS.VS1TriggerCount++; break;
                case 2: rtpResponse.VS.VS2TriggerCount++; break;
                case 3: rtpResponse.VS.VS3TriggerCount++; break;
                case 4: rtpResponse.VS.VS4TriggerCount++; break;
                case 5: rtpResponse.VS.VS5TriggerCount++; break;
            }
        }
        else
        {
            rtpResponse.VS.NonTriggeredVsWin += win;
        }
    }

    private BuyFreeSpinsParams GetBuyBonusParamsByFeature(string feature)
    {
        return feature.ToLower() switch
        {
            "duel" => GetBuyDuelBonusParams(),
            "train" => GetBuyTrainBonusParams(),
            "dead" => GetBuyDeadBonusParams(),
            _ => throw new ArgumentException($"Unknown feature: {feature}")
        };
    }

    private long GetBonusCost(string feature)
    {
        return feature.ToLower() switch
        {
            "duel" => 200 * 20,
            "train" => 80 * 20,
            "dead" => 400 * 20,
            _ => throw new ArgumentException($"Unknown feature: {feature}")
        };
    }

    private static void TrackWinDistribution(double totalWin, long bonusCost, BaronOilRtpData rtpResponse)
    {
        var winMultiplier = totalWin / bonusCost;

        if (totalWin == 0)
            rtpResponse.WinDistribution.Win0++;
        else if (winMultiplier < 0.5)
            rtpResponse.WinDistribution.Win0To05++;
        else if (winMultiplier < 1)
            rtpResponse.WinDistribution.Win05To1++;
        else if (winMultiplier < 2)
            rtpResponse.WinDistribution.Win1To2++;
        else if (winMultiplier < 3)
            rtpResponse.WinDistribution.Win2To3++;
        else if (winMultiplier < 5)
            rtpResponse.WinDistribution.Win3To5++;
        else if (winMultiplier < 10)
            rtpResponse.WinDistribution.Win5To10++;
        else if (winMultiplier < 15)
            rtpResponse.WinDistribution.Win10To15++;
        else if (winMultiplier < 20)
            rtpResponse.WinDistribution.Win15To20++;
        else if (winMultiplier < 30)
            rtpResponse.WinDistribution.Win20To30++;
        else if (winMultiplier < 50)
            rtpResponse.WinDistribution.Win30To50++;
        else if (winMultiplier < 75)
            rtpResponse.WinDistribution.Win50To75++;
        else if (winMultiplier < 100)
            rtpResponse.WinDistribution.Win75To100++;
        else if (winMultiplier < 150)
            rtpResponse.WinDistribution.Win100To150++;
        else
            rtpResponse.WinDistribution.Win150Plus++;
    }

    private void UpdateBuyBonusRtp(BaronOilRtpData rtpResponse, double userBalance, int totalBonuses, long bonusCost)
    {
        var totalSpent = (long)totalBonuses * bonusCost;
        var totalWon = rtpResponse.Win.FreeSpinsWin;
        var totalWonUncapped = rtpResponse.WinUncapped.FreeSpinsWin;

        var rtp = totalSpent > 0 ? (double)totalWon / totalSpent * 100 : 0;

        rtpResponse.Rtp = new RtpDetails
        {
            BaseGame = "0%",
            FreeSpins = $"{rtp:F4}%",
            Total = $"{rtp:F4}%"
        };

        rtpResponse.Win.TotalWin = totalWon;
        rtpResponse.Win.WinDelta = totalWon - totalSpent;
        rtpResponse.User.EndBalance = userBalance;
        rtpResponse.User.Delta = userBalance - rtpResponse.User.StartBalance;

        rtpResponse.WinUncapped.TotalWin = rtpResponse.WinUncapped.BaseGameWin + rtpResponse.WinUncapped.FreeSpinsWin;
        rtpResponse.WinUncapped.TotalLoose = totalSpent;
        rtpResponse.WinUncapped.WinDelta = rtpResponse.WinUncapped.TotalWin - totalSpent;
        rtpResponse.RtpUncapped = new RtpDetails
        {
            BaseGame = "0%",
            FreeSpins = totalSpent > 0 ? $"{(totalWonUncapped / totalSpent * 100):F4}%" : "0%",
            Total = totalSpent > 0 ? $"{(totalWonUncapped / totalSpent * 100):F4}%" : "0%"
        };

        rtpResponse.FreeSpins.StartedHitRate = 1;
        rtpResponse.FreeSpins.WildAppears.HitRate = rtpResponse.FreeSpins.WildAppears.Count > 0
            ? (double)rtpResponse.FreeSpins.TotalRoundsCount / rtpResponse.FreeSpins.WildAppears.Count
            : 0;

        rtpResponse.VS.HitRate = rtpResponse.VS.Count > 0
            ? (double)rtpResponse.FreeSpins.TotalRoundsCount / rtpResponse.VS.Count
            : 0;

        rtpResponse.VS.AverageWinningMultiplier = rtpResponse.VS.TotalBattles > 0
            ? (double)rtpResponse.VS.SumOfAllAppliedMultipliers / rtpResponse.VS.TotalBattles
            : 0;

        rtpResponse.VS.VsTriggerCycle = rtpResponse.VS.SpinsWithVsTriggered > 0
            ? (double)rtpResponse.FreeSpins.TotalRoundsCount / rtpResponse.VS.SpinsWithVsTriggered
            : 0;

        rtpResponse.VS.VsTriggeredPercent = rtpResponse.FreeSpins.TotalRoundsCount > 0
            ? (double)rtpResponse.VS.SpinsWithVsTriggered / rtpResponse.FreeSpins.TotalRoundsCount * 100
            : 0;

        rtpResponse.VS.VsAppearancesPercent = rtpResponse.FreeSpins.TotalRoundsCount > 0
            ? (double)rtpResponse.VS.Count / rtpResponse.FreeSpins.TotalRoundsCount * 100
            : 0;

        if (rtpResponse.FreeSpinsRtpData.Train.TriggeredCount > 0)
        {
            rtpResponse.FreeSpinsRtpData.Train.AverageWildsAdded =
                (double)rtpResponse.FreeSpinsRtpData.Train.TotalWildsAdded / rtpResponse.FreeSpinsRtpData.Train.TriggeredCount;
        }

        if (rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount > 0)
        {
            rtpResponse.FreeSpinsRtpData.Dead.AverageWilds =
                (double)rtpResponse.FreeSpinsRtpData.Dead.TotalWildsCollected / rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount;
            rtpResponse.FreeSpinsRtpData.Dead.AverageMultipliers =
                (double)rtpResponse.FreeSpinsRtpData.Dead.TotalMultipliersCollected / rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount;
        }
    }

    #endregion

    private async Task<SpinState> DoSpin(BaronOilRtpData rtpResponse, MachineState machineState)
    {
        var spinParams = GetSpinParams();
        var spinState = await _slotService.Spin(spinParams, machineState);

        UpdateSpinRtp(spinState, rtpResponse);

        return spinState;
    }

    private BaronOilRtpData GetInitialRtpResponse()
    {
        return new BaronOilRtpData
        {
            Win = new WinDetails(),
            VS = new BaronOilVSFeatureDetails()
            {
                Count = 0,
                HitRate = 0,
                VS1Count = 0,
                VS1TriggerCount = 0,
                VS2Count = 0,
                VS2TriggerCount = 0,
                VS3Count = 0,
                VS3TriggerCount = 0,
                VS4Count = 0,
                VS4TriggerCount = 0,
                VS5Count = 0,
                VS5TriggerCount = 0,
                AverageMultiplier = 0,
                MultiplierCount = 0,
                VsItemCount = 0,
            },
            PayStatics = [],
            TrainBonus = new BaronOilFeatureDetails()
            {
                Count = 0,
                HitRate = 0
            },
            DeadBonus = new BaronOilDeadBonusDetails()
            {
                WildCount = 0,
                MultiplierCount = 0,
                HitRate = 0
            },
            TrainMaxWin = 0,
            FreeSpins = new BaronOilFreeSpinsDetails
            {
                WildAppears = new BaronOilFeatureDetails(),
                MaxWinFeature = new BaronOilFeatureDetails()
            },
            FreeSpinsRtpData = new BaronOilExtendedRtpData()
            {
                Duel = new BaroinOilExtendedFreeSpin(),
                Train = new BaroinOilExtendedFreeSpin(),
                Dead = new BaroinOilExtendedFreeSpin()
            },
            User = new UserDetails
            {
                StartBalance = DefaultBalance
            }
        };
    }

    private void UpdateSpinRtp(SpinState spinState, BaronOilRtpData rtpResponse)
    {
        var machineState = spinState.MachineState;

        if (machineState.FreeSpinsInfo == null || machineState.FreeSpinsInfo.Event == FreeSpinsEvent.started)
        {
            rtpResponse.Win.BaseGameWin += machineState.TotalWin;
            rtpResponse.Win.TotalLoose += machineState.TotalLost;
            rtpResponse.WinUncapped.BaseGameWin += machineState.TotalWin;

            var gameType = BaronOilMachineStatePayload.GetBaseGameType(machineState.Payload);
            var win = machineState.TotalWin;
            var isHit = win > 0;

            if (gameType == BaronOilBaseGameTypeEnum.VS)
            {
                rtpResponse.BaseGameStats.VsSpinCount++;
                rtpResponse.BaseGameStats.VsWin += win;
                if (isHit) rtpResponse.BaseGameStats.VsHitCount++;
            }
            else
            {
                rtpResponse.BaseGameStats.NonVsSpinCount++;
                rtpResponse.BaseGameStats.NonVsWin += win;
                if (isHit) rtpResponse.BaseGameStats.NonVsHitCount++;
            }

            TrackVSInBaseGame(spinState, rtpResponse);
        }

        if (machineState.FreeSpinsInfo != null)
        {
            if (machineState.FreeSpinsInfo.Event == FreeSpinsEvent.started)
            {
                rtpResponse.FreeSpins.StartedCount += 1;
            }
            else if (machineState.FreeSpinsInfo.Event == FreeSpinsEvent.finished)
            {
                rtpResponse.Win.FreeSpinsWin += machineState.FreeSpinsInfo.TotalWin;
                rtpResponse.WinUncapped.FreeSpinsWin += GetUncappedFreeSpinsWin(machineState);
            }

            if (machineState.FreeSpinsInfo.Event != FreeSpinsEvent.started)
            {
                rtpResponse.FreeSpins.TotalRoundsCount += 1;
                UpdateWildDetails(spinState, rtpResponse);
            }

            if (machineState.WinningName == MachineConstants.MaxWin)
            {
                rtpResponse.FreeSpins.MaxWinFeature.Count += 1;
            }
        }
    }

    private void UpdateWildDetails(SpinState spinState, BaronOilRtpData rtpResponse)
    {
        var wildCount =
            spinState.MachineState.DefaultSpecGroups.Count(group => group.Type == DefaultSpecGroupType.Collector);
        rtpResponse.FreeSpins.WildAppears.Count += wildCount;
    }

    private static double GetUncappedFreeSpinsWin(MachineState machineState)
    {
        var maxWinGroup = machineState.DefaultSpecGroups
            .FirstOrDefault(group => group.Type == DefaultSpecGroupType.BigWinTotalWin);
        if (maxWinGroup?.TotalWinDouble > 0)
        {
            return maxWinGroup.TotalWinDouble;
        }

        return machineState.FreeSpinsInfo?.TotalWin ?? 0;
    }

    private void UpdateTotalRtp(BaronOilRtpData rtpResponse, double userBalance)
    {
        rtpResponse.Rtp = GetRtpDetails(rtpResponse);

        rtpResponse.Win.TotalWin = rtpResponse.Win.BaseGameWin + rtpResponse.Win.FreeSpinsWin;
        rtpResponse.Win.WinDelta = rtpResponse.Win.TotalWin - rtpResponse.Win.TotalLoose;

        rtpResponse.WinUncapped.TotalWin = rtpResponse.WinUncapped.BaseGameWin + rtpResponse.WinUncapped.FreeSpinsWin;
        rtpResponse.WinUncapped.TotalLoose = rtpResponse.Win.TotalLoose;
        rtpResponse.WinUncapped.WinDelta = rtpResponse.WinUncapped.TotalWin - rtpResponse.WinUncapped.TotalLoose;

        rtpResponse.User.EndBalance = userBalance;
        rtpResponse.User.Delta = rtpResponse.User.EndBalance - rtpResponse.User.StartBalance;

        rtpResponse.FreeSpins.StartedHitRate = rtpResponse.FreeSpins.StartedCount != 0
            ? (double)rtpResponse.TotalSpins / rtpResponse.FreeSpins.StartedCount
            : 0;
        rtpResponse.FreeSpins.WildAppears.HitRate = rtpResponse.FreeSpins.WildAppears.Count != 0
            ? (double)rtpResponse.TotalSpins / rtpResponse.FreeSpins.WildAppears.Count
            : 0;

        rtpResponse.FreeSpins.MaxWinFeature.HitRate = rtpResponse.FreeSpins.MaxWinFeature.Count != 0
            ? (double)rtpResponse.TotalSpins / rtpResponse.FreeSpins.MaxWinFeature.Count
            : 0;

        rtpResponse.VS.HitRate = rtpResponse.VS.Count != 0
            ? (double)rtpResponse.TotalSpins / rtpResponse.VS.Count
            : 0;

        rtpResponse.VS.AverageWinningMultiplier = rtpResponse.VS.TotalBattles > 0
            ? (double)rtpResponse.VS.SumOfAllAppliedMultipliers / rtpResponse.VS.TotalBattles
            : 0;

        rtpResponse.VS.VsTriggerCycle = rtpResponse.VS.SpinsWithVsTriggered > 0
            ? (double)rtpResponse.TotalSpins / rtpResponse.VS.SpinsWithVsTriggered
            : 0;

        rtpResponse.VS.VsTriggeredPercent = rtpResponse.TotalSpins > 0
            ? (double)rtpResponse.VS.SpinsWithVsTriggered / rtpResponse.TotalSpins * 100
            : 0;

        rtpResponse.VS.VsAppearancesPercent = rtpResponse.TotalSpins > 0
            ? (double)rtpResponse.VS.Count / rtpResponse.TotalSpins * 100
            : 0;

        var totalLoose = rtpResponse.Win.TotalLoose;
        if (totalLoose > 0)
        {
            var nonVsRtp = rtpResponse.BaseGameStats.NonVsWin / totalLoose * 100;
            var vsRtp = rtpResponse.BaseGameStats.VsWin / totalLoose * 100;
            rtpResponse.BaseGameStats.NonVsRtp = $"{nonVsRtp:F4}%";
            rtpResponse.BaseGameStats.VsRtp = $"{vsRtp:F4}%";
        }

        if (rtpResponse.BaseGameStats.NonVsSpinCount > 0)
        {
            var nonVsHitRate = (double)rtpResponse.BaseGameStats.NonVsHitCount / rtpResponse.BaseGameStats.NonVsSpinCount * 100;
            rtpResponse.BaseGameStats.NonVsHitRate = $"{nonVsHitRate:F4}%";
        }

        if (rtpResponse.BaseGameStats.VsSpinCount > 0)
        {
            var vsHitRate = (double)rtpResponse.BaseGameStats.VsHitCount / rtpResponse.BaseGameStats.VsSpinCount * 100;
            rtpResponse.BaseGameStats.VsHitRate = $"{vsHitRate:F4}%";
        }

        if (rtpResponse.Win.TotalLoose > 0)
        {
            var uncappedFreeSpinsRtp = rtpResponse.WinUncapped.FreeSpinsWin / rtpResponse.Win.TotalLoose * 100;
            var uncappedTotalRtp = rtpResponse.WinUncapped.TotalWin / rtpResponse.Win.TotalLoose * 100;
            rtpResponse.RtpUncapped = new RtpDetails
            {
                BaseGame = rtpResponse.Rtp.BaseGame,
                FreeSpins = $"{uncappedFreeSpinsRtp:F4}%",
                Total = $"{uncappedTotalRtp:F4}%"
            };
        }

        if (rtpResponse.FreeSpinsRtpData.Train.TriggeredCount > 0)
        {
            rtpResponse.FreeSpinsRtpData.Train.AverageWildsAdded =
                (double)rtpResponse.FreeSpinsRtpData.Train.TotalWildsAdded / rtpResponse.FreeSpinsRtpData.Train.TriggeredCount;
        }

        if (rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount > 0)
        {
            rtpResponse.FreeSpinsRtpData.Dead.AverageWilds =
                (double)rtpResponse.FreeSpinsRtpData.Dead.TotalWildsCollected / rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount;
            rtpResponse.FreeSpinsRtpData.Dead.AverageMultipliers =
                (double)rtpResponse.FreeSpinsRtpData.Dead.TotalMultipliersCollected / rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount;
        }
    }

    protected void UpdateIntermediateRtp(RtpData rtpResponse, int totalSpins)
    {
        if (rtpResponse.TotalSpins % IntermediateResult == 0 && rtpResponse.TotalSpins != totalSpins)
        {
            rtpResponse.IntermediateRtp ??= new List<RtpDetails>();
            rtpResponse.IntermediateRtp.Insert(0, GetRtpDetails(rtpResponse, rtpResponse.TotalSpins));
        }
    }

    protected SpinParams GetSpinParams()
    {
        return new SpinParams
        {
            Bet = 20,
            MachineId = MachineId
        };
    }
    protected BuyFreeSpinsParams GetBuyTrainBonusParams()
    {
        return new BuyFreeSpinsParams
        {
            Bet = 20,
            MachineId = MachineId,
            Feature = BaronOilBuyFeatures.Train
        };
    }
    protected BuyFreeSpinsParams GetBuyDeadBonusParams()
    {
        return new BuyFreeSpinsParams
        {
            Bet = 20,
            MachineId = MachineId,
            Feature = BaronOilBuyFeatures.Dead
        };
    }
    protected BuyFreeSpinsParams GetBuyDuelBonusParams()
    {
        return new BuyFreeSpinsParams
        {
            Bet = 20,
            MachineId = MachineId,
            Feature = BaronOilBuyFeatures.Duel
        };
    }

    private static void CollectFreeSpinsRtpData(MachineState machineState, BaronOilRtpData rtpResponse)
    {
        var freeSpinsType = machineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;
        if (freeSpinsType == BaronOilScatterTypeEnum.Duel.ToString())
        {
            rtpResponse.FreeSpinsRtpData.Duel.TriggeredCount += 1;
            rtpResponse.FreeSpinsRtpData.Duel.SpinCount += machineState.FreeSpinsInfo!.CurrentFreeSpinsGroup.UsedCount;
            rtpResponse.FreeSpinsRtpData.Duel.TotalWin += machineState.FreeSpinsInfo!.TotalWin;
            rtpResponse.FreeSpinsRtpData.Duel.BaseGameWin += machineState.FreeSpinsInfo!.BaseGameWin;
        }
        if (freeSpinsType == BaronOilScatterTypeEnum.Train.ToString())
        {
            rtpResponse.FreeSpinsRtpData.Train.TriggeredCount += 1;
            rtpResponse.FreeSpinsRtpData.Train.SpinCount += machineState.FreeSpinsInfo!.CurrentFreeSpinsGroup.UsedCount;
            rtpResponse.FreeSpinsRtpData.Train.TotalWin += machineState.FreeSpinsInfo!.TotalWin;
            rtpResponse.FreeSpinsRtpData.Train.BaseGameWin += machineState.FreeSpinsInfo!.BaseGameWin;
            rtpResponse.FreeSpinsRtpData.Train.TotalWildsAdded += BaronOilMachineStatePayload.GetTrainAddedWildsCount(machineState.Payload);
        }
        if (freeSpinsType == BaronOilScatterTypeEnum.Dead.ToString())
        {
            rtpResponse.FreeSpinsRtpData.Dead.TriggeredCount += 1;
            rtpResponse.FreeSpinsRtpData.Dead.SpinCount += machineState.FreeSpinsInfo!.CurrentFreeSpinsGroup.UsedCount;
            rtpResponse.FreeSpinsRtpData.Dead.TotalWin += machineState.FreeSpinsInfo!.TotalWin;
            rtpResponse.FreeSpinsRtpData.Dead.BaseGameWin += machineState.FreeSpinsInfo!.BaseGameWin;

            var wildGroup = machineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Collector);
            var multiplierGroup = machineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Multiplier);
            rtpResponse.FreeSpinsRtpData.Dead.TotalWildsCollected += wildGroup?.CollectCount ?? 0;
            rtpResponse.FreeSpinsRtpData.Dead.TotalMultipliersCollected += multiplierGroup?.CollectCount ?? 0;
        }
    }
}
