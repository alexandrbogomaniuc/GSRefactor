using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Models.Params;
using CGS.SlotEngine.Slot;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil;

public class BaronOilSlotMachine<TConfig>(int machineId, string config)
    : SlotMachine<TConfig>(machineId, config), ISlotMachine<TConfig>
    where TConfig : BaronOilSlotConfig
{
    public List<ISpinSlotFeature<TConfig>> BuyBonusTrainFeatures { get; init; } = [];
    public List<ISpinSlotFeature<TConfig>> BuyBonusDeadFeatures { get; init; } = [];
    public List<ISpinSlotFeature<TConfig>> BuyBonusDuelFeatures { get; init; } = [];

    async Task<SpinState> ISlotMachine<TConfig>.BuyFreeSpins(
        MachineState machineState,
        BuyFreeSpinsParams buyFreeSpinsParams
    )
    {
        var spinState = BuildSpinState(machineState);
        var spinContext = BuildSpinContext(buyFreeSpinsParams.ConvertToSpinParams());

        List<ISpinSlotFeature<TConfig>> features;

        switch (buyFreeSpinsParams.Feature)
        {
            case BaronOilBuyFeatures.Train:
                features = BuyBonusTrainFeatures;
                break;

            case BaronOilBuyFeatures.Dead:
                features = BuyBonusDeadFeatures;
                break;

            case BaronOilBuyFeatures.Duel:
                features = BuyBonusDuelFeatures;
                break;

            default:
                throw new InvalidOperationException("Invalid feature selected for buy free spins.");
        }

        foreach (var feature in features)
        {
            spinState = await feature.Execute(spinState, spinContext);
        }

        return spinState;
    }
    
    bool ISlotMachine<TConfig>.ValidateBuyFreeSpinsBalance(MachineState machineState,
        BuyFreeSpinsParams buyFreeSpinsParams, double userBalance)
    {
        var totalBet = buyFreeSpinsParams.Bet * Config.BaseLines * Config.TranBuyBonus;
        return userBalance >= totalBet;
    }

}