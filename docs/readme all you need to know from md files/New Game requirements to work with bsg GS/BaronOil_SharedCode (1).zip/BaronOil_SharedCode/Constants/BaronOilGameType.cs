namespace CGS.Games.Slots.BaronOil.Constants;

public enum BaronOilBaseGameTypeEnum
{
    Empty,
    VS,
    Scatter,
}
