namespace CGS.Games.Slots.BaronOil.Constants;

public enum BaronOilDeadFeatureEnum
{
    Empty,
    Collect,
    ShowDown,
}