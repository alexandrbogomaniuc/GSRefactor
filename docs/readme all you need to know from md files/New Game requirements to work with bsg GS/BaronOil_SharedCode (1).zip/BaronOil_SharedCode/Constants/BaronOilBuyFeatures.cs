namespace CGS.Games.Slots.BaronOil.Constants;

public static class BaronOilBuyFeatures
{
    public const string Empty = "Empty";
    public const string Train = "Train";
    public const string Duel = "Duel";
    public const string Dead = "Dead";
    public static readonly string[] All = [Train];
} 


public enum BaronOilScatterTypeEnum
{
    Empty,
    Duel,
    Dead,
    Train,
}