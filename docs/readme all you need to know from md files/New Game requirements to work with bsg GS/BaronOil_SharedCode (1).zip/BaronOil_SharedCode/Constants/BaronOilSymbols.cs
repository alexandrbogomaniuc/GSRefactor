namespace CGS.Games.Slots.BaronOil.Constants;

public static class BaronOilSymbols
{
    public const int WildSymbolId = 1;
    public const int DuelSymbolId = 12;
    public const int DeadSymbolId = 13;
    public const int TrainSymbolId = 14;
    public const int MultiplierSymbolId = 15;
    public const int PlaceholderSymbolId = 17;
    public const int StickyWildSymbolId = 18;
}