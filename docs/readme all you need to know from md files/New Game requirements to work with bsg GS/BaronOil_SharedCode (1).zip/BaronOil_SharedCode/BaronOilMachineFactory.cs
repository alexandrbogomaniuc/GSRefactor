
using CGS.Common.Attributes;
using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Features.Bet;
using CGS.Games.Slots.BaronOil.Features.BuyBonus;
using CGS.Games.Slots.BaronOil.Features.BuyBonus.Dead;
using CGS.Games.Slots.BaronOil.Features.BuyBonus.Duel;
using CGS.Games.Slots.BaronOil.Features.BuyBonus.Train;
using CGS.Games.Slots.BaronOil.Features.Spin;
using CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins;
using CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;
using CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Duel;
using CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Train;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Slot;
using CGS.SlotEngine.Slot.Features.BuyFreeSpins;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Features.Spin.Cheat;
using CGS.SlotEngine.Slot.Features.Spin.Condition;
using CGS.SlotEngine.Slot.Features.Spin.FreeSpins;
using CGS.SlotEngine.Slot.Features.Start;
using CGS.SlotEngine.Slot.Models.Config;
using CGS.SlotEngine.Utilities.SpinId;

namespace CGS.Games.Slots.BaronOil;

[Scoped(typeof(ISlotMachineFactory<SlotConfig>), "machine8")]
public class BaronOilMachineFactory(IRandomizer randomizer, ISpinIdGenerator spinIdGenerator) : ISlotMachineFactory<BaronOilSlotConfig>
{
    private const int MachineId = 8;

    public ISlotMachine<BaronOilSlotConfig> BuildSlotMachine(string config)
    {
        var slotMachine = new BaronOilSlotMachine<BaronOilSlotConfig>(MachineId, config)
        {
            StartFeatures = GetStartSlotFeatures(),
            SpinFeatures = GetSpinFeatures(),
            BuyBonusTrainFeatures = GetBuyBonusTrainFeatures(),
            BuyBonusDeadFeatures = GetBuyBonusDeadFeatures(),
            BuyBonusDuelFeatures = GetBuyBonusDuelFeatures()
        };

        return slotMachine;
    }

    private List<IStartSlotFeature<BaronOilSlotConfig>> GetStartSlotFeatures()
    {
        return
        [
            new SetStartStateFieldsFeature<BaronOilSlotConfig>(),
        ];
    }

    private List<ISpinSlotFeature<BaronOilSlotConfig>> GetSpinFeatures()
    {
        var viewReelsGeneratorFeature = new ConditionForkFeature<BaronOilSlotConfig>(
            CheatViewReelsGeneratorFeature<BaronOilSlotConfig>.IsReelsPositionsCheat,
            new ViewReelsGeneratorFeature<BaronOilSlotConfig>(randomizer),
            new CheatViewReelsGeneratorFeature<BaronOilSlotConfig>()
        );

        var baseGameFeatures = new List<ISpinSlotFeature<BaronOilSlotConfig>>
        {
            new BaronOilBaseGameSelectorFeature<BaronOilSlotConfig>(randomizer),
            viewReelsGeneratorFeature,
            new BaronOilVSFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBaseGameWinlineFeature<BaronOilSlotConfig>(),
            new BaronOilBaseGameAddScatterToViewReelsFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBaseGameScatterTriggerFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerDuelFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerTrainFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerDeadFeature<BaronOilSlotConfig>(),
        };

        var freeSpinViewReelsGeneratorFeature = new ConditionForkFeature<BaronOilSlotConfig>(
            CheatViewReelsGeneratorFeature<BaronOilSlotConfig>.IsReelsPositionsCheat,
            [new ViewReelsGeneratorFeature<BaronOilSlotConfig>(randomizer)],
            [new CheatViewReelsGeneratorFeature<BaronOilSlotConfig>()]
        );

        var endFreeSpinsRoundFeature = new ConditionForkFeature<BaronOilSlotConfig>(
            CheatEndFreeSpinsFeature<BaronOilSlotConfig>.IsDoFreeSpinsToEndCheat,
            [new EndFreeSpinsRoundFeature<BaronOilSlotConfig>()],
            [new CheatEndFreeSpinsFeature<BaronOilSlotConfig>()]
        );

        var freeSpinsFeatures = new List<ISpinSlotFeature<BaronOilSlotConfig>>
        {
            new BaronOilFreeSpinsTrainPreviousWildPositionsFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsReelSelectorDuelFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsReelSelectorDeadFeature<BaronOilSlotConfig>(),
            freeSpinViewReelsGeneratorFeature,
            endFreeSpinsRoundFeature,
            new BaronOilFreeSpinsViewReelGeneratorDeadFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilFreeSpinTrainFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilFreeSpinsDuelFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilFreeSpinDeadFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilFreeSpinsPhaseTriggerDeadFeature<BaronOilSlotConfig>(randomizer),
            new UpdateFreeSpinsTotalWinFeature<BaronOilSlotConfig>(),
            new BaronOilMaxWinFeature<BaronOilSlotConfig>(),
            new BaronOilEndFreeSpinsRoundFeature<BaronOilSlotConfig>()
        };

        var gameForkFeature = new ConditionForkFeature<BaronOilSlotConfig>(
            GameModeSelectorFeature<BaronOilSlotConfig>.IsFreeSpins,
            baseGameFeatures,
            freeSpinsFeatures
        );

        return [
            new BaronOilCheckSpinMachineStateFeature<BaronOilSlotConfig>(),
            new GameModeSelectorFeature<BaronOilSlotConfig>(),
            new SpinIdFeature<BaronOilSlotConfig>(spinIdGenerator),
            new BaronOilSetBetFeature<BaronOilSlotConfig>(),
            new BeforeSpinUpdateTotalLostFeature<BaronOilSlotConfig>(),
            gameForkFeature,
            new SpecialWinningsFeature<BaronOilSlotConfig>(),
        ];
    }

    private List<ISpinSlotFeature<BaronOilSlotConfig>> GetBuyBonusTrainFeatures()
    {
        return [
            new BaronOilCheckSpinMachineStateFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusReelSelectorFeature<BaronOilSlotConfig>(),
            new BaroinOilBuyBonusTrainFeature<BaronOilSlotConfig>(),
            new GameModeSelectorFeature<BaronOilSlotConfig>(),
            new ValidateBuyFreeSpinsFeature<BaronOilSlotConfig>(),
            new SpinIdFeature<BaronOilSlotConfig>(spinIdGenerator),
            new BaronOilSetBetFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusTotalLostTrainFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusViewReelsGeneratorFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBuyBonusTrainScattersSelectorFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBaseGameScatterTriggerFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerTrainFeature<BaronOilSlotConfig>(),
        ];
    }

    private List<ISpinSlotFeature<BaronOilSlotConfig>> GetBuyBonusDeadFeatures()
    {
        return [
            new BaronOilCheckSpinMachineStateFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusReelSelectorFeature<BaronOilSlotConfig>(),
            new BaroinOilBuyBonusDeadFeature<BaronOilSlotConfig>(),
            new GameModeSelectorFeature<BaronOilSlotConfig>(),
            new ValidateBuyFreeSpinsFeature<BaronOilSlotConfig>(),
            new SpinIdFeature<BaronOilSlotConfig>(spinIdGenerator),
            new BaronOilSetBetFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusTotalLostDeadFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusViewReelsGeneratorFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBuyBonusScattersSelectorDeadFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBaseGameScatterTriggerFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerDeadFeature<BaronOilSlotConfig>(),
        ];
    }

    private List<ISpinSlotFeature<BaronOilSlotConfig>> GetBuyBonusDuelFeatures()
    {
        return [
            new BaronOilCheckSpinMachineStateFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusReelSelectorFeature<BaronOilSlotConfig>(),
            new BaroinOilBuyBonusDuelFeature<BaronOilSlotConfig>(),
            new GameModeSelectorFeature<BaronOilSlotConfig>(),
            new ValidateBuyFreeSpinsFeature<BaronOilSlotConfig>(),
            new SpinIdFeature<BaronOilSlotConfig>(spinIdGenerator),
            new BaronOilSetBetFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusTotalLostDuelFeature<BaronOilSlotConfig>(),
            new BaronOilBuyBonusViewReelsGeneratorFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBuyBonusScattersSelectorDuelFeature<BaronOilSlotConfig>(randomizer),
            new BaronOilBaseGameScatterTriggerFeature<BaronOilSlotConfig>(),
            new BaronOilFreeSpinsScatterTriggerDuelFeature<BaronOilSlotConfig>(),
        ];
    }
}
