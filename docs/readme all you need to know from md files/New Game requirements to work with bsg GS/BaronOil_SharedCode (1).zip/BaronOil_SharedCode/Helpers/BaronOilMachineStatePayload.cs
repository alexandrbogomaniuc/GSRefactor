using CGS.Games.Slots.BaronOil.Constants;
using CGS.SlotEngine.Helpers;

namespace CGS.Games.Slots.BaronOil.Helpers;

public enum PayloadKey
{
    BaseGameType,
    TrainWildPositions,
    TrainAddedWildsCount,
    BuyBonusFeature,
    DeadReelSet,
    DeadFreeSpinsPhase,
    DeadFreeSpinsWildPositions,
    RTPVSData,
}

public static class BaronOilMachineStatePayload
{
    public static void AddBaseGameTypePayload(BaronOilBaseGameTypeEnum baseGameType, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.BaseGameType, baseGameType, payload);
    }

    public static BaronOilBaseGameTypeEnum GetBaseGameType(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload(PayloadKey.BaseGameType, payload, BaronOilBaseGameTypeEnum.Empty);
    }

    public static void AddTrainWildPositionsPayload(List<(int reel, int line)> trainWildPositions, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.TrainWildPositions, trainWildPositions, payload);
    }

    public static List<(int reel, int line)> GetTrainWildPositions(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload<List<(int reel, int line)>>(PayloadKey.TrainWildPositions, payload, []);
    }

    public static void AddTrainAddedWildsCount(int wildsCount, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.TrainAddedWildsCount, wildsCount, payload);
    }

    public static int GetTrainAddedWildsCount(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload(PayloadKey.TrainAddedWildsCount, payload, 0);
    }

    public static void AddBuyBonusFeature(string buyBonusFeature, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.BuyBonusFeature, buyBonusFeature, payload);
    }

    public static string GetBuyBonusFeature(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload(PayloadKey.BuyBonusFeature, payload, BaronOilBuyFeatures.Empty);
    }

    public static void AddDeadReelSet(int[][] deadReelSet, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.DeadReelSet, deadReelSet, payload);
    }

    public static int[][] GetDeadReelSet(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload<int[][]>(PayloadKey.DeadReelSet, payload, []);
    }

    public static void AddDeadFreeSpinsPhase(BaronOilDeadFeatureEnum deadFreeSpinsPhase, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.DeadFreeSpinsPhase, deadFreeSpinsPhase, payload);
    }

    public static BaronOilDeadFeatureEnum GetDeadFreeSpinsPhase(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload(PayloadKey.DeadFreeSpinsPhase, payload, BaronOilDeadFeatureEnum.Empty);
    }

    public static void AddDeadFreeSpinsWildPositions(List<int> deadFreeSpinsWildPositions, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.DeadFreeSpinsWildPositions, deadFreeSpinsWildPositions, payload);
    }

    public static List<int> GetDeadFreeSpinsWildPositions(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload<List<int>>(PayloadKey.DeadFreeSpinsWildPositions, payload, []);
    }

    public static void AddRTPVSData(Dictionary<string, object> rtpVSData, List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.AddPayload(PayloadKey.RTPVSData, rtpVSData, payload);
    }

    public static Dictionary<string, object> GetRTPVSData(List<Dictionary<string, object>>? payload)
    {
        return MachineStatePayload.GetPayload<Dictionary<string, object>>(PayloadKey.RTPVSData, payload, []);
    }

    public static void RemoveRTPVSData(List<Dictionary<string, object>> payload)
    {
        MachineStatePayload.RemovePayload(PayloadKey.RTPVSData, payload);
    }
    
}
