using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.BuyBonus.Train;

public class BaroinOilBuyBonusTrainFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        BaronOilMachineStatePayload.AddBuyBonusFeature(BaronOilBuyFeatures.Train, newMachineState.Payload!);

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }
}