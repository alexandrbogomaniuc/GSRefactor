using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.BuyBonus;

public class BaronOilBuyBonusViewReelsGeneratorFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var reels = spinState.ReelSet!;

        var viewReels = new int[spinContext.SlotConfig.ReelsWidth][];

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            viewReels[i] = new int[spinContext.SlotConfig.ReelsHeight];
            var startIndex = await GetStartIndex(reels, i);

            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                var index = (startIndex + j) % reels[i].Length;
                viewReels[i][j] = reels[i][index];
            }
        }

        newMachineState.ViewReels = viewReels;

        var viewReelsExtracted = ReelsHelper.ExtractViewReels(viewReels);

        return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);
    }

    private async Task<int> GetStartIndex(int[][] reelSet, int rowIndex)
    {
        return await randomizer.Random(reelSet[rowIndex].Length);
    }
}