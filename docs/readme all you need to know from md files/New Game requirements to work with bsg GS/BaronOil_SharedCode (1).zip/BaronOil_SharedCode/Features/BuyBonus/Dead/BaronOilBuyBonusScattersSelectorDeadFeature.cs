using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.BuyBonus.Dead;

public class BaronOilBuyBonusScattersSelectorDeadFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();
        var newViewReels = newMachineState.ViewReels!;

        var totalPositions = spinContext.SlotConfig.ReelsHeight * spinContext.SlotConfig.ReelsWidth;
        var possiblePositions = Enumerable.Range(0, totalPositions).ToList();
        var deadPositions = await randomizer.GetRandoms(spinContext.SlotConfig.DeadPositionsCount, possiblePositions);

        foreach (var position in deadPositions)
        {
            var reel = position / spinContext.SlotConfig.ReelsWidth;
            var line = position % spinContext.SlotConfig.ReelsHeight;
            newViewReels[reel][line] = BaronOilSymbols.DeadSymbolId;
        }

        newMachineState.ViewReels = newViewReels;

        var viewReelsExtracted = ReelsHelper.ExtractViewReels(newViewReels);

        return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);
    }
}