using CGS.Common.Utilities;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.BuyBonus.Dead;

public class BaronOilBuyBonusTotalLostDeadFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var totalLost = NumberFormat.RoundDouble(
            spinContext.SlotConfig.BaseLines *
            spinContext.SpinParams.Bet *
            spinContext.SlotConfig.DeadBuyBonus
        );

        var newMachineState = (MachineState)spinState.MachineState.Clone();
        newMachineState.TotalLost = totalLost;

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }
}