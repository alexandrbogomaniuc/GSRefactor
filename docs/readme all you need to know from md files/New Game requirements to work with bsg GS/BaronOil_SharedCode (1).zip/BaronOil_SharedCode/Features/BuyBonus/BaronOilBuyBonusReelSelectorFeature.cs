using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.BuyBonus;

public class BaronOilBuyBonusReelSelectorFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();
        newMachineState.Payload ??= [];

        var reelSet = spinContext.SlotConfig.BuyBonusBaseReelSet;
        return Task.FromResult(spinState.With(reelSet: reelSet, machineState: newMachineState));
    }
}