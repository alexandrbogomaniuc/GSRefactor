using CGS.Common.Utilities;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Bet;

public class BaronOilSetBetFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {

        if (spinState.GameMode == SpinGameMode.FreeSpins)
        {
            return Task.FromResult(spinState.With(bet: spinState.MachineState.FreeSpinsInfo!.CurrentFreeSpinsGroup.Bet));
        }

        double betMultiplier = 1.0 / spinContext.SlotConfig.BetMultiplier;

        var baseGameBet = NumberFormat.RoundDouble(spinContext.SpinParams.Bet * betMultiplier);


        return Task.FromResult(spinState.With(bet: baseGameBet));
    }
}