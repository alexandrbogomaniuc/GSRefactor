using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Train;

public class BaronOilFreeSpinsTrainPreviousWildPositionsFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Train.ToString())
        {
            return Task.FromResult(spinState);
        }

        var reelSet = spinContext.SlotConfig.TrainFreeSpinsReelSet;
        var viewReels = spinState.MachineState.ViewReels!;
        var previousWildPositions = new List<(int reel, int line)>();

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                if (viewReels[i][j] == BaronOilSymbols.StickyWildSymbolId)
                {
                    previousWildPositions.Add((i, j));
                }
            }
        }

        BaronOilMachineStatePayload.AddTrainWildPositionsPayload(previousWildPositions, spinState.MachineState.Payload!);
        return Task.FromResult(spinState.With(machineState: spinState.MachineState, reelSet: reelSet));
    }
}