using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;

public class BaronOilFreeSpinsScatterTriggerDeadFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Dead.ToString())
        {
            return Task.FromResult(spinState);
        }

        var scatterInfo = spinContext.SlotConfig.ScattersInfo.FirstOrDefault();
        if (scatterInfo == null)
        {
            return Task.FromResult(spinState);
        }

        var newMachineState = (MachineState)spinState.MachineState.Clone();

        BaronOilMachineStatePayload.AddDeadFreeSpinsPhase(BaronOilDeadFeatureEnum.Collect, newMachineState.Payload!);

        newMachineState.FreeSpinsInfo = BaronOilBaseGameScatterTriggerFeature<T>.BuildFreeSpinsInfo(spinState, spinContext, scatterInfo.DeadFreeSpinsAmount);
        newMachineState.FreeSpinsInfo!.Bin = FreeSpinsBin.Bin1;

        newMachineState.DefaultSpecGroups.Add(CreateMultiplierGroup());
        newMachineState.DefaultSpecGroups.Add(CreateWildGroup());

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }

    private static DefaultSpecGroup CreateMultiplierGroup()
    {
        return new DefaultSpecGroup
        {
            Type = DefaultSpecGroupType.Multiplier,
            CollectCount = 1,
            PreviousSymbolId = 0,
            SymbolId = BaronOilSymbols.MultiplierSymbolId,
            TotalWin = 0,
            TotalWinDouble = 0,
            Positions = [],
        };
    }

    private static DefaultSpecGroup CreateWildGroup()
    {
        return new DefaultSpecGroup
        {
            Type = DefaultSpecGroupType.Collector,
            CollectCount = 0,
            PreviousSymbolId = 0,
            SymbolId = BaronOilSymbols.WildSymbolId,
            TotalWin = 0,
            TotalWinDouble = 0,
            Positions = [],
        };
    }
}