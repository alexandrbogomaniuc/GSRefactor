using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;

public class BaronOilFreeSpinsReelSelectorDeadFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Dead.ToString())
        {
            return Task.FromResult(spinState);
        }


        var reels = BaronOilMachineStatePayload.GetDeadReelSet(spinState.MachineState.Payload!);
        if (reels == null || reels.Length == 0)
        {
            var isBuyBonus = BaronOilMachineStatePayload.GetBuyBonusFeature(spinState.MachineState.Payload!) == BaronOilBuyFeatures.Dead;

            reels = isBuyBonus ? spinContext.SlotConfig.BuyBonusDeadCollectReelSet : spinContext.SlotConfig.DeadCollectReelSet;
            int[][] reelSet = [.. reels.Select(row => (int[])row.Clone())];

            var newMachineState = (MachineState)spinState.MachineState.Clone();

            BaronOilMachineStatePayload.AddDeadReelSet(reelSet, newMachineState.Payload!);

            return Task.FromResult(spinState.With(reelSet: reelSet, machineState: newMachineState));
        }

        return Task.FromResult(spinState.With(reelSet: reels));
    }
}