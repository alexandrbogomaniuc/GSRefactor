using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Duel;

public class BaronOilFreeSpinsScatterTriggerDuelFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Duel.ToString())
        {
            return Task.FromResult(spinState);
        }

        var scatterInfo = spinContext.SlotConfig.ScattersInfo.FirstOrDefault();
        if (scatterInfo == null)
        {
            return Task.FromResult(spinState);
        }

        var newMachineState = (MachineState)spinState.MachineState.Clone();
        newMachineState.FreeSpinsInfo = BaronOilBaseGameScatterTriggerFeature<T>.BuildFreeSpinsInfo(spinState, spinContext, scatterInfo.DuelFreeSpinsAmount);

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }
}