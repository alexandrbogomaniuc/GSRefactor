using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Train;

public class BaronOilFreeSpinTrainFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Train.ToString())
        {
            return spinState;
        }

        var previousTrainWildPositions = BaronOilMachineStatePayload.GetTrainWildPositions(spinState.MachineState.Payload);
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var isBuyBonusTrain = BaronOilMachineStatePayload.GetBuyBonusFeature(newMachineState.Payload) == BaronOilBuyFeatures.Train;
        var freeSpinsWilds = isBuyBonusTrain ? spinContext.SlotConfig.TrainBuyBonusWilds : spinContext.SlotConfig.TrainFreeSpinsWilds;
        var trainWilds = await WeightedItemSelector.GetRandomItem(randomizer, freeSpinsWilds);

        var newViewReels = newMachineState.ViewReels!;

        var possibleWildPositions = new List<(int reel, int line)>();

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                if(!previousTrainWildPositions.Contains((i, j)))
                {
                    possibleWildPositions.Add((i, j));
                }
            }
        }

        var possibleCount = trainWilds.Count > possibleWildPositions.Count ? possibleWildPositions.Count : trainWilds.Count;

        var positions = await randomizer.GetRandoms(possibleCount, possibleWildPositions);

        var payload = newMachineState.Payload!;
        var currentAddedWilds = BaronOilMachineStatePayload.GetTrainAddedWildsCount(payload);
        BaronOilMachineStatePayload.AddTrainAddedWildsCount(currentAddedWilds + positions.Count, payload);

        foreach ((int reel, int line) in positions)
        {
            newViewReels[reel][line] = BaronOilSymbols.StickyWildSymbolId;
        }

        foreach ((int reel, int line) in previousTrainWildPositions)
        {
            newViewReels[reel][line] = BaronOilSymbols.StickyWildSymbolId;
        }

        newMachineState.ViewReels = newViewReels;
        
        var viewReelsExtracted = ReelsHelper.ExtractViewReels(newViewReels);

        var metaWin = WinLineCalculator.CalculateWin(
            spinContext.SymbolsContainer,
            spinContext.SlotConfig.Lines,
            viewReelsExtracted,
            spinState.Bet
        );

        newMachineState.TotalWin += metaWin.TotalWin;
        newMachineState.WinLines = [..metaWin.WinLines];


        BaronOilMachineStatePayload.AddTrainWildPositionsPayload([], newMachineState.Payload!);

        return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);
    }
}
