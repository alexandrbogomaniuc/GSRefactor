using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Slot.Features.Spin.FreeSpins;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins;

public class BaronOilMaxWinFeature<T> : MaxWinFeature<T> where T : BaronOilSlotConfig
{
    protected override int GetMaxWin(T slotConfig)
    {
        return slotConfig.MaxWin;
    }
}
