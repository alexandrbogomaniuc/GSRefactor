using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;

public class BaronOilFreeSpinDeadFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Dead.ToString())
        {
            return Task.FromResult(spinState);
        }

        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var deadFreeSpinsPhase = BaronOilMachineStatePayload.GetDeadFreeSpinsPhase(newMachineState.Payload!);

        if (deadFreeSpinsPhase == BaronOilDeadFeatureEnum.Collect)
        {
            return Task.FromResult(CollectPhaseFeature(spinState, spinContext));
        }

        return Task.FromResult(ShowDownPhaseFeature(spinState, spinContext));
    }

    private static SpinState CollectPhaseFeature(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();
        var wildPositions = new List<int>();
        var multiplierPositions = new List<int>();

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                var position = j * spinContext.SlotConfig.ReelsWidth + i;
                if (newMachineState.ViewReels![i][j] == BaronOilSymbols.WildSymbolId)
                {
                    wildPositions.Add(position);
                    continue;
                }
                if (newMachineState.ViewReels![i][j] == BaronOilSymbols.MultiplierSymbolId)
                {
                    multiplierPositions.Add(position);
                }
            }
        }

        if (wildPositions.Count > 0)
        {
            var wildGroup = newMachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Collector)!;

            newMachineState.DefaultSpecGroups = DefaultSpecGroupManager.RemoveGroupsByType(newMachineState.DefaultSpecGroups, DefaultSpecGroupType.Collector);

            wildGroup.CollectCount += wildPositions.Count;
            wildGroup.Positions = [.. wildPositions];

            newMachineState.DefaultSpecGroups.Add(wildGroup);
        }

        if (multiplierPositions.Count > 0)
        {
            var multiplierGroup = newMachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Multiplier)!;

            newMachineState.DefaultSpecGroups = DefaultSpecGroupManager.RemoveGroupsByType(newMachineState.DefaultSpecGroups, DefaultSpecGroupType.Multiplier);

            multiplierGroup.CollectCount += multiplierPositions.Count;
            multiplierGroup.Positions = [.. multiplierPositions];

            newMachineState.DefaultSpecGroups.Add(multiplierGroup);
        }

        return spinState.With(machineState: newMachineState);
    }
    
    private static SpinState ShowDownPhaseFeature(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();
        var multiplierGroup = newMachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Multiplier)!;

        var metaWin = WinLineCalculator.CalculateWin(
            spinContext.SymbolsContainer,
            spinContext.SlotConfig.Lines,
            spinState.ViewReelsExtracted!,
            spinState.Bet,
            multiplierGroup.CollectCount
        );

        if (metaWin.WinLines.Count > 0)
        {
            newMachineState.TotalWin += metaWin.TotalWin;
            newMachineState.WinLines = [.. metaWin.WinLines];
        }

        return spinState.With(machineState: newMachineState);
    }
}