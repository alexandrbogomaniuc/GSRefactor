using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;

public class BaronOilFreeSpinsViewReelGeneratorDeadFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Dead.ToString())
        {
            return spinState;
        }

        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var deadFreeSpinsPhase = BaronOilMachineStatePayload.GetDeadFreeSpinsPhase(newMachineState.Payload!);


        var viewReels = new int[spinContext.SlotConfig.ReelsWidth][];
        var viewReelsExtracted = new int[spinContext.SlotConfig.ReelsWidth * spinContext.SlotConfig.ReelsHeight];

        if (deadFreeSpinsPhase == BaronOilDeadFeatureEnum.Collect)
        {
            var reelSet = spinState.ReelSet!;

            (viewReels, int[][] newReelSet) = await GenerateCollectPhaseViewReel(reelSet, spinContext);

            spinState.ReelSet = newReelSet;

            BaronOilMachineStatePayload.AddDeadReelSet(newReelSet, newMachineState.Payload!);

            newMachineState.ViewReels = viewReels;

            viewReelsExtracted = ReelsHelper.ExtractViewReels(viewReels);

            return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);
        }

        if (deadFreeSpinsPhase == BaronOilDeadFeatureEnum.ShowDown)
        {
            var reelSet = spinState.ReelSet!;

            (viewReels, int[][] newReelSet) = await GenerateShowDownPhaseViewReel(reelSet, spinContext, newMachineState);
            
            spinState.ReelSet = newReelSet;
            newMachineState.ViewReels = viewReels;


            viewReelsExtracted = ReelsHelper.ExtractViewReels(viewReels);

            return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);
        }

        return spinState;
    }

    private async Task<(int[][], int[][])> GenerateCollectPhaseViewReel(int[][] reelSet, SpinContext<T> spinContext)
    {
        var viewReels = new int[spinContext.SlotConfig.ReelsWidth][];

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            viewReels[i] = new int[spinContext.SlotConfig.ReelsHeight];
            var startIndex = await GetStartIndex(reelSet, i);

            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                var lineIndex = (startIndex + j) % reelSet[i].Length;
                var symbol = reelSet[i][lineIndex];
                viewReels[i][j] = symbol;

                if (symbol == BaronOilSymbols.WildSymbolId || symbol == BaronOilSymbols.MultiplierSymbolId)
                {
                    reelSet[i][lineIndex] = BaronOilSymbols.PlaceholderSymbolId;
                }
            }
        }

        return (viewReels, reelSet);
    }

    private async Task<(int[][], int[][])> GenerateShowDownPhaseViewReel(int[][] reels, SpinContext<T> spinContext, MachineState newMachineState)
    {
        var viewReels = new int[spinContext.SlotConfig.ReelsWidth][];
        var wildPositions = BaronOilMachineStatePayload.GetDeadFreeSpinsWildPositions(newMachineState.Payload!);

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            viewReels[i] = new int[spinContext.SlotConfig.ReelsHeight];
            var startIndex = await GetStartIndex(reels, i);

            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                var index = (startIndex + j) % reels[i].Length;
                var symbol = reels[i][index];
                viewReels[i][j] = symbol;

                var position = j * spinContext.SlotConfig.ReelsWidth + i;
                if (wildPositions.Contains(position))
                {
                    viewReels[i][j] = BaronOilSymbols.WildSymbolId;
                }
            }
        }

        return (viewReels, reels);
    }

    private async Task<int> GetStartIndex(int[][] reelSet, int rowIndex)
    {
        return await randomizer.Random(reelSet[rowIndex].Length);
    }
}