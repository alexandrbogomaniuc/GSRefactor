using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Duel;

public class BaronOilFreeSpinsReelSelectorDuelFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Duel.ToString())
        {
            return Task.FromResult(spinState);
        }


        var reels = spinContext.SlotConfig.DuelFreeSpinsReelSet;

        return Task.FromResult(spinState.With(reelSet: reels));
    }
}