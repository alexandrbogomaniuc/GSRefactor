using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Dead;

public class BaronOilFreeSpinsPhaseTriggerDeadFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Dead.ToString())
        {
            return spinState;
        }

        var deadFreeSpinsPhase = BaronOilMachineStatePayload.GetDeadFreeSpinsPhase(spinState.MachineState.Payload!);

        var scatterInfo = spinContext.SlotConfig.ScattersInfo.FirstOrDefault()!;


        if (deadFreeSpinsPhase == BaronOilDeadFeatureEnum.Collect && spinState.MachineState.FreeSpinsInfo!.Event == FreeSpinsEvent.finished)
        {
            var hasSpecialSymbols = spinState.ViewReelsExtracted!.Any(symbol => symbol == BaronOilSymbols.WildSymbolId || symbol == BaronOilSymbols.MultiplierSymbolId);

            if (hasSpecialSymbols)
            {
                return CollectPhaseFeature(spinState, scatterInfo.DeadFreeSpinsAmount);
            }

            return await MoveToShowDownPhaseFeature(spinState, spinContext, scatterInfo.DeadFreeSpinsAmount);
        }

        if (deadFreeSpinsPhase == BaronOilDeadFeatureEnum.Collect)
        {
            return CollectPhaseFeature(spinState, scatterInfo.DeadFreeSpinsAmount);
        }

        return spinState;
    }

    private static SpinState CollectPhaseFeature(SpinState spinState, int deadFreeSpinsAmount)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var hasSpecialSymbols = newMachineState.ViewReels!.Any(row => row.Any(symbol => symbol == BaronOilSymbols.WildSymbolId || symbol == BaronOilSymbols.MultiplierSymbolId));

        if (!hasSpecialSymbols)
        {
            return spinState;
        }

        var freeSpinsAdded = deadFreeSpinsAmount - spinState.MachineState.FreeSpinsInfo!.CurrentFreeSpinsGroup.Count;

        if (freeSpinsAdded > 0)
        {
            newMachineState.FreeSpinsInfo!.Event = FreeSpinsEvent.added;
            newMachineState.FreeSpinsInfo!.FreeSpinsAdded = freeSpinsAdded;
            newMachineState.FreeSpinsInfo.CurrentFreeSpinsGroup.Count = deadFreeSpinsAmount;
        }

        return spinState.With(machineState: newMachineState);
    }

    private async Task<SpinState> MoveToShowDownPhaseFeature(SpinState spinState, SpinContext<T> spinContext, int deadFreeSpinsAmount)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        newMachineState.FreeSpinsInfo!.Event = FreeSpinsEvent.added;
        newMachineState.FreeSpinsInfo!.FreeSpinsAdded = deadFreeSpinsAmount;
        newMachineState.FreeSpinsInfo!.Bin = FreeSpinsBin.Bin2;
        newMachineState.FreeSpinsInfo.CurrentFreeSpinsGroup.Count = deadFreeSpinsAmount;

        BaronOilMachineStatePayload.AddDeadFreeSpinsPhase(BaronOilDeadFeatureEnum.ShowDown, newMachineState.Payload!);

        var isBuyBonus = BaronOilMachineStatePayload.GetBuyBonusFeature(spinState.MachineState.Payload!) == BaronOilBuyFeatures.Dead;
        var reels = isBuyBonus ? spinContext.SlotConfig.BuyBonusDeadShowDownReelSet : spinContext.SlotConfig.DeadShowDownReelSet;

        int[][] reelSet = [.. reels.Select(row => (int[])row.Clone())];
        BaronOilMachineStatePayload.AddDeadReelSet(reelSet, newMachineState.Payload!);

        var wildGroup = newMachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.Collector)!;
        var totalPositions = spinContext.SlotConfig.ReelsWidth * spinContext.SlotConfig.ReelsHeight;
        var possibleWildPositions = Enumerable.Range(0, totalPositions).ToList();
        var wildPositions = await randomizer.GetRandoms(wildGroup.CollectCount, possibleWildPositions);

        BaronOilMachineStatePayload.AddDeadFreeSpinsWildPositions(wildPositions, newMachineState.Payload!);

        return spinState.With(machineState: newMachineState);
    }
}