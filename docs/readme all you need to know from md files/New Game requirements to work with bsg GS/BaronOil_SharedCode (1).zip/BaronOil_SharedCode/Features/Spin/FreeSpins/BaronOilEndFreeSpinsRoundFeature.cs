using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins;

public class BaronOilEndFreeSpinsRoundFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        if (spinState.MachineState.FreeSpinsInfo == null || spinState.MachineState.FreeSpinsInfo.Event != FreeSpinsEvent.finished)
        {
            return Task.FromResult(spinState);
        }

        var newMachineState = (MachineState)spinState.MachineState.Clone();

        var buyBonusFeature = BaronOilMachineStatePayload.GetBuyBonusFeature(newMachineState.Payload);
        var rtpVSData = BaronOilMachineStatePayload.GetRTPVSData(newMachineState.Payload);
        var trainAddedWildsCount = BaronOilMachineStatePayload.GetTrainAddedWildsCount(newMachineState.Payload);

        newMachineState.Payload = [];

        if (buyBonusFeature != BaronOilBuyFeatures.Empty)
        {
            BaronOilMachineStatePayload.AddBuyBonusFeature(buyBonusFeature, newMachineState.Payload);
        }

        if (rtpVSData != null && rtpVSData.Count > 0)
        {
            BaronOilMachineStatePayload.AddRTPVSData(rtpVSData, newMachineState.Payload);
        }

        if (trainAddedWildsCount > 0)
        {
            BaronOilMachineStatePayload.AddTrainAddedWildsCount(trainAddedWildsCount, newMachineState.Payload);
        }

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }
}
