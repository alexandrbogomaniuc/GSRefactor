using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin.FreeSpins.Duel;

public class BaronOilFreeSpinsDuelFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterType = spinState.MachineState.DefaultSpecGroups.FirstOrDefault(group => group.Type == DefaultSpecGroupType.FreeSpinType)?.SubType;

        if (scatterType == null || scatterType != BaronOilScatterTypeEnum.Duel.ToString())
        {
            return spinState;
        }

        var isBuyBonusDuel = BaronOilMachineStatePayload.GetBuyBonusFeature(spinState.MachineState.Payload) == BaronOilBuyFeatures.Duel;
        var vsConfig = isBuyBonusDuel ? spinContext.SlotConfig.BuyBonusVS : spinContext.SlotConfig.DuelFreeSpinsVS;
        var vsMultipliers = spinContext.SlotConfig.BuyBonusVSMultipers;

        return await BaronOilVSFeature<T>.VSFeature(randomizer, spinContext, spinState, vsConfig, vsMultipliers);
    }
}