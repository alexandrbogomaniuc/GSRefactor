using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilBaseGameScatterTriggerFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var scatterSymbols = spinState.ViewReelsExtracted?
            .Select((x, index) => new { Index = index, Symbol = x })
            .Where(item => spinContext.SymbolsContainer.IsScatterSymbol(item.Symbol))
            .ToArray() ?? [];

        if (scatterSymbols.Length == 0)
        {
            return Task.FromResult(spinState);
        }

        var scatterInfo = spinContext.SlotConfig.ScattersInfo.FirstOrDefault();
        if (scatterInfo == null || scatterSymbols.Length < scatterInfo.ScattersAmount)
        {
            return Task.FromResult(spinState);
        }

        var firstScatterSymbol = scatterSymbols.First().Symbol;
        var scatterType = GetScatterTypeBySymbol(firstScatterSymbol);
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        newMachineState.DefaultSpecGroups = [CreateFreeSpinsGroup(firstScatterSymbol, scatterType)];

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }

    public static BaronOilScatterTypeEnum GetScatterTypeBySymbol(int symbolId)
    {
        return symbolId switch
        {
            BaronOilSymbols.DuelSymbolId => BaronOilScatterTypeEnum.Duel,
            BaronOilSymbols.DeadSymbolId => BaronOilScatterTypeEnum.Dead,
            BaronOilSymbols.TrainSymbolId => BaronOilScatterTypeEnum.Train,
            _ => throw new Exception("Invalid scatter symbol"),
        };
    }

    public static FreeSpinsInfo BuildFreeSpinsInfo(SpinState spinState, SpinContext<T> spinContext, int freeSpinsAmount)
    {
        var machineState = spinState.MachineState;
        var baseGameWin = machineState.TotalWin;

        var freeSpinsInfo = new FreeSpinsInfo
        {
            Event = FreeSpinsEvent.started,
            FreeSpinsAdded = freeSpinsAmount,
            Name = FreeSpinsName.free,
            TotalFreeSpins = 0,
            TotalWin = 0,
            BaseGameWin = baseGameWin
        };

        var freeSpinsGroup = new FreeSpinsGroup
        {
            Bet = spinState.Bet,
            BetCalculation = BetCalculation.Default,
            Count = freeSpinsAmount,
            Multiplier = 1,
            Lines = spinContext.SlotConfig.Lines.Length,
            Name = FreeSpinsName.free,
            UsedCount = 0,
            Win = 0,
        };

        freeSpinsInfo.AddNewFreeSpinsGroup(freeSpinsGroup);


        return freeSpinsInfo;
    }

    public static DefaultSpecGroup CreateFreeSpinsGroup(int symbolId, BaronOilScatterTypeEnum subType)
    {

        return new DefaultSpecGroup
        {
            Type = DefaultSpecGroupType.FreeSpinType,
            SubType = subType.ToString(),
            CollectCount = 0,
            PreviousSymbolId = 0,
            SymbolId = symbolId,
            TotalWin = 0,
            TotalWinDouble = 0
        };
    }
}