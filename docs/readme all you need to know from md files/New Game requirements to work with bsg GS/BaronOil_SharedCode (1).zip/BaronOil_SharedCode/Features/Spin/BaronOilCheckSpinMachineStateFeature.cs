using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilCheckSpinMachineStateFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        UpdateFreeSpinsInfoBeforeSpin(newMachineState);
        UpdateTotalWin(newMachineState);
        CheckDefaultSpecGroups(newMachineState);

        newMachineState.WinningName = null;
        newMachineState.WinLines = [];
        newMachineState.WinPositions = [];

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }

    private static void UpdateTotalWin(MachineState machineState)
    {
        machineState.TotalWin = 0;
    }

    private static void UpdateFreeSpinsInfoBeforeSpin(MachineState machineState)
    {
        if (machineState.FreeSpinsInfo != null)
        {
            machineState.FreeSpinsInfo.FreeSpinsAdded = 0;

            if (machineState.FreeSpinsInfo.Event == FreeSpinsEvent.finished)
            {
                machineState.DefaultSpecGroups = DefaultSpecGroupManager.RemoveGroupsByType(
                    machineState.DefaultSpecGroups,
                    DefaultSpecGroupType.FreeSpinType,
                    DefaultSpecGroupType.Multiplier,
                    DefaultSpecGroupType.Collector
                );
                machineState.FreeSpinsInfo = null;
                machineState.Payload = [];
            }
            else
            {
                machineState.FreeSpinsInfo.Event = null;
            }
        }
    }

    private static void CheckDefaultSpecGroups(MachineState machineState)
    {
        machineState.DefaultSpecGroups = DefaultSpecGroupManager.RemoveGroupsByType(
            machineState.DefaultSpecGroups,
            DefaultSpecGroupType.BigWinTotalWin
        );
    }
}