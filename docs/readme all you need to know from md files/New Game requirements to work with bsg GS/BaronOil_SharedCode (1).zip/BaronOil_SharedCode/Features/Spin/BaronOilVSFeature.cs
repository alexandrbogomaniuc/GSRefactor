using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilVSFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var gameType = BaronOilMachineStatePayload.GetBaseGameType(spinState.MachineState.Payload);

        if (gameType != BaronOilBaseGameTypeEnum.VS)
        {
            return spinState;
        }

        return await VSFeature(randomizer, spinContext, spinState, spinContext.SlotConfig.VS, spinContext.SlotConfig.VSMultipers);
    }

    public static async Task<SpinState> VSFeature(IRandomizer randomizer, SpinContext<T> spinContext, SpinState spinState, BaronOilSlotConfigVS[] configVS, BaronOilSlotConfigVSMultiplier[] configVSMultipers)
    {
        var newMachineState = (MachineState)spinState.MachineState.Clone();

        int[][] newViewReels = newMachineState.ViewReels!;

        var vsItem = await WeightedItemSelector.GetRandomItem(randomizer, configVS);

        var reels = new List<int>();
        var reel = await WeightedItemSelector.GetRandomItem(randomizer, vsItem.ReelWeights);

        reels.AddRange(reel.Reels);

        if (vsItem.Count > 2)
        {
            for (var i = 1; i < vsItem.Count; i++)
            {
                var reelsWeights = vsItem.ReelWeights.Where((x) => !reels.Contains(x.Reels.First())).ToArray();

                reel = await WeightedItemSelector.GetRandomItem(randomizer, reelsWeights);
                reels.AddRange(reel.Reels);
            }
        }

        var vsPoisitions = new HashSet<int>();

        var rows = Enumerable.Range(0, spinContext.SlotConfig.ReelsHeight).ToArray();
        int[][] originalViewReels = [.. newViewReels.Select(arr => arr.ToArray())];
        int[][] vsNewViewReels = [.. newViewReels.Select(arr => arr.ToArray())];
        var wildSymbolId = spinContext.SymbolsContainer.GetWildSymbols().First();

        for (var i = 0; i < reels.Count; i++)
        {
            var reelIndex = reels[i];
            var filteredRows = rows.Where(rowIndex => newViewReels[reelIndex][rowIndex] != wildSymbolId).ToArray();
            var reelRows = await randomizer.Shuffle(filteredRows);
            var reelRow = reelRows.First();

            newViewReels[reelIndex][reelRow] = BaronOilSlotConfigConstants.VSIconId;

            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                vsNewViewReels[reelIndex][j] = wildSymbolId;
                var position = j * spinContext.SlotConfig.ReelsWidth + reelIndex;
                vsPoisitions.Add(position);
            }
        }

        var vsNewViewReelsExtracted = ReelsHelper.ExtractViewReels(vsNewViewReels);

        var vsMetaWin = WinLineCalculator.CalculateWin(
           spinContext.SymbolsContainer,
           spinContext.SlotConfig.Lines,
           vsNewViewReelsExtracted,
           spinState.Bet
       );


        var isFeatureTriggered = vsMetaWin.WinLines.Any(winLine => winLine.Positions!.Any(poisition => vsPoisitions.Contains(poisition)));

        if (!isFeatureTriggered)
        {
            var originalExtracted = ReelsHelper.ExtractViewReels(originalViewReels);

            var metaWin = WinLineCalculator.CalculateWin(
                spinContext.SymbolsContainer,
                spinContext.SlotConfig.Lines,
                originalExtracted,
                spinState.Bet
            );

            var rtpVSNonTriggeredData = new Dictionary<string, object>
            {
                { "TotalWin", metaWin.TotalWin },
                { "VsItemCount", vsItem.Count },
                { "Multiplier", 1 },
            };
            BaronOilMachineStatePayload.AddRTPVSData(rtpVSNonTriggeredData, newMachineState.Payload!);

            newMachineState.TotalWin += metaWin.TotalWin;
            newMachineState.WinLines = [..metaWin.WinLines];
            return spinState.With(machineState: newMachineState, viewReelsExtracted: ReelsHelper.ExtractViewReels(newViewReels));
        }

        var totalMultiplier = 0;

        foreach (var vsReelIndex in reels)
        {
            var firstMultiplier = await WeightedItemSelector.GetRandomItem(randomizer, configVSMultipers);

            var secondMultiplier = firstMultiplier;

            while (secondMultiplier.Multiplier == firstMultiplier.Multiplier)
            {
                secondMultiplier = await WeightedItemSelector.GetRandomItem(randomizer, configVSMultipers);
            }

            var multiplierDifference = Math.Abs(firstMultiplier.Multiplier - secondMultiplier.Multiplier);

            var vsWinnerRules = spinContext.SlotConfig.VSWinnerRules.Where(x => x.Difference >= multiplierDifference).ToArray().First();

            var vsWinnerRule = await WeightedItemSelector.GetRandomItem(randomizer, vsWinnerRules.Weights);

            int winnerMultiplier;

            if (vsWinnerRule.Result > 0)
            {
                winnerMultiplier = firstMultiplier.Multiplier > secondMultiplier.Multiplier ? firstMultiplier.Multiplier : secondMultiplier.Multiplier;
            }
            else
            {
                winnerMultiplier = firstMultiplier.Multiplier < secondMultiplier.Multiplier ? firstMultiplier.Multiplier : secondMultiplier.Multiplier;
            }

            totalMultiplier += winnerMultiplier;

        }

        var finalMultiplier = totalMultiplier > 0 ? totalMultiplier : 1;
        newMachineState.TotalWin += vsMetaWin.TotalWin * finalMultiplier;

        var rtpVSTriggeredData = new Dictionary<string, object>
        {
            { "TotalWin", newMachineState.TotalWin },
            { "VsItemCount", vsItem.Count },
            { "Multiplier", finalMultiplier },
            { "BaseWin", vsMetaWin.TotalWin },
        };
        BaronOilMachineStatePayload.AddRTPVSData(rtpVSTriggeredData, newMachineState.Payload!);


        newMachineState.WinLines = [..vsMetaWin.WinLines];

        return spinState.With(machineState: newMachineState, viewReelsExtracted: ReelsHelper.ExtractViewReels(newViewReels));
    }
}
