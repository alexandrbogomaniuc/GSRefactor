using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilBaseGameSelectorFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T>
    where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var baseGameType = await WeightedItemSelector.GetRandomItem(randomizer, spinContext.SlotConfig.BaseGameType);
        
        var reelSet = spinContext.SlotConfig.BaseSet;

        var newMachineState = (MachineState)spinState.MachineState.Clone();
        newMachineState.Payload = [];

        BaronOilMachineStatePayload.AddBaseGameTypePayload(baseGameType.Type, newMachineState.Payload!);

        return spinState.With(reelSet: reelSet, machineState: newMachineState);
    }
}