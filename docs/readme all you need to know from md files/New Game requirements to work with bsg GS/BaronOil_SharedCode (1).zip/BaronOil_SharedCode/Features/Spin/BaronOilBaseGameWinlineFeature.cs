using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilBaseGameWinlineFeature<T> : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var gameType = BaronOilMachineStatePayload.GetBaseGameType(spinState.MachineState.Payload);

        if (gameType == BaronOilBaseGameTypeEnum.VS)
        {
            return Task.FromResult(spinState);
        }

        var metaWin = WinLineCalculator.CalculateWin(
            spinContext.SymbolsContainer,
            spinContext.SlotConfig.Lines,
            spinState.ViewReelsExtracted!,
            spinState.Bet
        );

        var newMachineState = (MachineState)spinState.MachineState.Clone();
        newMachineState.WinLines = [.. metaWin.WinLines];

        if (metaWin.WinLines.Count > 0)
        {
            newMachineState.TotalWin += metaWin.TotalWin;
        }

        return Task.FromResult(spinState.With(machineState: newMachineState));
    }
}