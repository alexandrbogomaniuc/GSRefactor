using CGS.Common.Utilities.Randomizer;
using CGS.Games.Slots.BaronOil.Constants;
using CGS.Games.Slots.BaronOil.Helpers;
using CGS.Games.Slots.BaronOil.Models.Config;
using CGS.SlotEngine.Models.Machine;
using CGS.SlotEngine.Slot.Features.Spin;
using CGS.SlotEngine.Slot.Helpers;
using CGS.SlotEngine.Slot.Models.Spin;

namespace CGS.Games.Slots.BaronOil.Features.Spin;

public class BaronOilBaseGameAddScatterToViewReelsFeature<T>(IRandomizer randomizer) : ISpinSlotFeature<T> where T : BaronOilSlotConfig
{
    public async Task<SpinState> Execute(SpinState spinState, SpinContext<T> spinContext)
    {
        var gameType = BaronOilMachineStatePayload.GetBaseGameType(spinState.MachineState.Payload);

        if (gameType != BaronOilBaseGameTypeEnum.Scatter)
        {
            return spinState;
        }

        var scatterCount = await WeightedItemSelector.GetRandomItem(randomizer, spinContext.SlotConfig.Scatter);
        var scatterType = await WeightedItemSelector.GetRandomItem(randomizer, spinContext.SlotConfig.ScatterType);

        var newMachineState = (MachineState)spinState.MachineState.Clone();
        var possibleScatterPositions = new List<int>();

        var viewReels = newMachineState.ViewReels!;

        for (var i = 0; i < spinContext.SlotConfig.ReelsWidth; i++)
        {
            for (var j = 0; j < spinContext.SlotConfig.ReelsHeight; j++)
            {
                possibleScatterPositions.Add(j * spinContext.SlotConfig.ReelsHeight + i);
            }
        }

        foreach (var winLine in newMachineState.WinLines!)
        {
            foreach (var position in winLine.Positions!)
            {
                possibleScatterPositions.Remove(position);
            }
        }

        var scatterPositions = await randomizer.GetRandoms(scatterCount.Count, possibleScatterPositions);

        foreach (var position in scatterPositions)
        {
            var reel = position % spinContext.SlotConfig.ReelsWidth;
            var line = position / spinContext.SlotConfig.ReelsHeight;

            viewReels[reel][line] = GetScatterSymbolId(scatterType.Type);
        }

        newMachineState.ViewReels = viewReels;

        var viewReelsExtracted = ReelsHelper.ExtractViewReels(viewReels);

        return spinState.With(machineState: newMachineState, viewReelsExtracted: viewReelsExtracted);

    }

    private static int GetScatterSymbolId(BaronOilScatterTypeEnum scatterType)
    {
        return scatterType switch
        {
            BaronOilScatterTypeEnum.Duel => BaronOilSymbols.DuelSymbolId,
            BaronOilScatterTypeEnum.Dead => BaronOilSymbols.DeadSymbolId,
            BaronOilScatterTypeEnum.Train => BaronOilSymbols.TrainSymbolId,
            _ => throw new Exception("Invalid scatter type"),
        };
    }
}